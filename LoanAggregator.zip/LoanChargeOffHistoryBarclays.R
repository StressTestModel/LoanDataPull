LoanChargeOffHistoryBarclays <- function (IDRSSD) {
  #Write a function to generate time-series data for individual banks - Loan and Charge-Off Data as well as Charge-Off Rates
  
  #Output NA for all observations up to (excluding) 2009Q1
  Nobserve <- 23; #Number of missing observations
  
  ChargeOff_1a <- matrix(NA,Nobserve,1); Loan_1a <- matrix(NA,Nobserve,1); ChargeOff_1b <- matrix(NA,Nobserve,1); 
  Loan_1b <- matrix(NA,Nobserve,1); 
  ChargeOff_1c1 <- matrix(NA,Nobserve,1); Loan_1c1 <- matrix(NA,Nobserve,1); ChargeOff_1c2 <- matrix(NA,Nobserve,1); 
  Loan_1c2 <- matrix(NA,Nobserve,1); ChargeOff_1d <- matrix(NA,Nobserve,1); Loan_1d <- matrix(NA,Nobserve,1); 
  ChargeOff_1e <- matrix(NA,Nobserve,1);
  Loan_1e <- matrix(NA,Nobserve,1); ChargeOff_2a <- matrix(NA,Nobserve,1); Loan_2a <- matrix(NA,Nobserve,1); 
  ChargeOff_2b <- matrix(NA,Nobserve,1);
  Loan_2b <- matrix(NA,Nobserve,1); ChargeOff_2c <- matrix(NA,Nobserve,1); Loan_2c <- matrix(NA,Nobserve,1);
  ChargeOff_3 <- matrix(NA,Nobserve,1); Loan_3 <- matrix(NA,Nobserve,1); ChargeOff_4a <- matrix(NA,Nobserve,1); 
  Loan_4a <- matrix(NA,Nobserve,1);
  ChargeOff_4b <- matrix(NA,Nobserve,1); Loan_4b <- matrix(NA,Nobserve,1); ChargeOff_5a <- matrix(NA,Nobserve,1); 
  Loan_5a <- matrix(NA,Nobserve,1);
  ChargeOff_5b <- matrix(NA,Nobserve,1); Loan_5b <- matrix(NA,Nobserve,1);  ChargeOff_5c <- matrix(NA,Nobserve,1); 
  Loan_5c <- matrix(NA,Nobserve,1);
  ChargeOff_6 <- matrix(NA,Nobserve,1); Loan_6 <- matrix(NA,Nobserve,1); 
  ChargeOff_7 <- matrix(NA,Nobserve,1); Loan_7 <- matrix(NA,Nobserve,1); ChargeOff_8a <- matrix(NA,Nobserve,1); 
  Loan_8a <- matrix(NA,Nobserve,1);
  ChargeOff_8b <- matrix(NA,Nobserve,1); Loan_8b <- matrix(NA,Nobserve,1); ChargeOff_9 <- matrix(NA,Nobserve,1); 
  Loan_9 <- matrix(NA,Nobserve,1);
  
  NewJack <- data.frame(ChargeOff_1a, ChargeOff_1b, ChargeOff_1c1, ChargeOff_1c2, ChargeOff_1d, ChargeOff_1e, ChargeOff_2a, 
                        ChargeOff_2b, ChargeOff_2c, ChargeOff_3, ChargeOff_4a, ChargeOff_4b, ChargeOff_5a, ChargeOff_5b, ChargeOff_5c, ChargeOff_6, 
                        ChargeOff_7, ChargeOff_8a, ChargeOff_8b, ChargeOff_9,Loan_1a, Loan_1b, Loan_1c1, Loan_1c2, Loan_1d, Loan_1e, 
                        Loan_2a, Loan_2b, Loan_2c, Loan_3, Loan_4a, Loan_4b, Loan_5a, Loan_5b, Loan_5c, Loan_6, Loan_7, Loan_8a, Loan_8b, 
                        Loan_9, ChargeOff_1a/Loan_1a, ChargeOff_1b/Loan_1b, ChargeOff_1c1/Loan_1c1, 
                        ChargeOff_1c2/Loan_1c2, ChargeOff_1d/Loan_1d, ChargeOff_1e/Loan_1e, 
                        ChargeOff_2a/Loan_2a, ChargeOff_2b/Loan_2b, ChargeOff_2c/Loan_2c, 
                        ChargeOff_3/Loan_3, ChargeOff_4a/Loan_4a, ChargeOff_4b/Loan_4b, 
                        ChargeOff_5a/Loan_5a, ChargeOff_5b/Loan_5b, ChargeOff_5c/Loan_5c, ChargeOff_6/Loan_6, 
                        ChargeOff_7/Loan_7, ChargeOff_8a/Loan_8a, ChargeOff_8b/Loan_8b, 
                        ChargeOff_9/Loan_9);
  
  names(NewJack)[41:60] <- c("GCO Rate_1a","GCO Rate_1b","GCO Rate_1c1","GCO Rate_1c2","GCO Rate_1d",
                             "GCO Rate_1e","GCO Rate_2a","GCO Rate_2b","GCO Rate_2c","GCO Rate_3","GCO Rate_4a","GCO Rate_4b",
                             "GCO Rate_5a","GCO Rate_5b","GCO Rate_5c","GCO Rate_6","GCO Rate_7",
                             "GCO Rate_8a","GCO Rate_8b","GCO Rate_9");
  #Get rid of the first 32 observations
  
  #The function inputs an IDRSSD, but don't use it - just define a local variable
  #IDRSSD <- 2980209; #Barclays Bank in Delaware as of 12/2006
  
  #December 31st, 2006
  sumDep122006 <- subset(bankData6,Reporting.Period.End.Date=="12/31/2006")
  ChargeOffData122006 <- read.csv("FFIEC CDR Call Schedule RIBI 12312006.csv",header=TRUE);
  LoanData122006      <- read.csv("FFIEC CDR Call Schedule RCCI 12312006.csv",header=TRUE);
  
  #Indust_Loans_CH_24   <- LoanCharge2a(sumDep122006,ChargeOffData122006,LoanData122006);
  Indust_Loans_CH_24   <- BankLoanGCDataNew2(sumDep122006,ChargeOffData122006,LoanData122006,IDRSSD);
  
  #2007
  bankData7 <- read.csv("bank_level_data_7a.csv",header=TRUE);
  
  #March 31st, 2007
  #sumDep2 <- subset(bankData2,Reporting.Period.End.Date=="3/31/2002")
  sumDep032007 <- subset(bankData7,Reporting.Period.End.Date=="3/31/2007")
  ChargeOffData032007 <- read.csv("FFIEC CDR Call Schedule RIBI 03312007.csv",header=TRUE);
  LoanData032007      <- read.csv("FFIEC CDR Call Schedule RCCI 03312007.csv",header=TRUE);
  
  #Indust_Loans_CH_25   <- LoanCharge4a(sumDep032007,ChargeOffData032007,LoanData032007);
  Indust_Loans_CH_25   <- BankLoanGCDataNew3(sumDep032007,ChargeOffData032007,LoanData032007,IDRSSD);
  
  #June 30th, 2007
  sumDep062007        <- subset(bankData7,Reporting.Period.End.Date=="6/30/2007")
  ChargeOffData062007 <- read.csv("FFIEC CDR Call Schedule RIBI 06302007.csv",header=TRUE);
  LoanData062007      <- read.csv("FFIEC CDR Call Schedule RCCI 06302007.csv",header=TRUE);
  
  #Indust_Loans_CH_26   <- LoanCharge4a(sumDep062007,ChargeOffData062007,LoanData062007);
  Indust_Loans_CH_26   <- BankLoanGCDataNew3(sumDep062007,ChargeOffData062007,LoanData062007,IDRSSD);
  
  #September 30th, 2007
  sumDep092007 <- subset(bankData7,Reporting.Period.End.Date=="9/30/2007")
  ChargeOffData092007 <- read.csv("FFIEC CDR Call Schedule RIBI 09302007.csv",header=TRUE);
  LoanData092007      <- read.csv("FFIEC CDR Call Schedule RCCI 09302007.csv",header=TRUE);
  
  #Indust_Loans_CH_27   <- LoanCharge4a(sumDep092007,ChargeOffData092007,LoanData092007);
  Indust_Loans_CH_27   <- BankLoanGCDataNew3(sumDep092007,ChargeOffData092007,LoanData092007,IDRSSD);
  
  #December 31st, 2007
  sumDep122007 <- subset(bankData7,Reporting.Period.End.Date=="12/31/2007")
  ChargeOffData122007 <- read.csv("FFIEC CDR Call Schedule RIBI 12312007.csv",header=TRUE);
  LoanData122007      <- read.csv("FFIEC CDR Call Schedule RCCI 12312007.csv",header=TRUE);
  
  #Indust_Loans_CH_28   <- LoanCharge4a(sumDep122007,ChargeOffData122007,LoanData122007);
  Indust_Loans_CH_28   <- BankLoanGCDataNew3(sumDep122007,ChargeOffData122007,LoanData122007,IDRSSD);
  
  #2008
  bankData8 <- read.csv("bank_level_data_8a.csv",header=TRUE);
  
  #March 31st, 2008
  #sumDep2 <- subset(bankData2,Reporting.Period.End.Date=="3/31/2002")
  sumDep032008 <- subset(bankData8,Reporting.Period.End.Date=="3/31/2008")
  ChargeOffData032008 <- read.csv("FFIEC CDR Call Schedule RIBI 03312008.csv",header=TRUE);
  LoanData032008      <- read.csv("FFIEC CDR Call Schedule RCCI 03312008.csv",header=TRUE);
  
  #Indust_Loans_CH_29   <- LoanCharge5a1(sumDep032008,ChargeOffData032008,LoanData032008);
  Indust_Loans_CH_29   <- BankLoanGCDataNew4(sumDep032008,ChargeOffData032008,LoanData032008,IDRSSD);
  
  #June 30th, 2008
  sumDep062008        <- subset(bankData8,Reporting.Period.End.Date=="6/30/2008")
  ChargeOffData062008 <- read.csv("FFIEC CDR Call Schedule RIBI 06302008.csv",header=TRUE);
  LoanData062008      <- read.csv("FFIEC CDR Call Schedule RCCI 06302008.csv",header=TRUE);
  
  #Indust_Loans_CH_30   <- LoanCharge5a1(sumDep062008,ChargeOffData062008,LoanData062008);
  Indust_Loans_CH_30   <- BankLoanGCDataNew4(sumDep062008,ChargeOffData062008,LoanData062008,IDRSSD);
  
  #September 30th, 2008
  sumDep092008 <- subset(bankData8,Reporting.Period.End.Date=="9/30/2008")
  ChargeOffData092008 <- read.csv("FFIEC CDR Call Schedule RIBI 09302008.csv",header=TRUE);
  LoanData092008      <- read.csv("FFIEC CDR Call Schedule RCCI 09302008.csv",header=TRUE);
  
  #Indust_Loans_CH_31   <- LoanCharge5a1(sumDep092008,ChargeOffData092008,LoanData092008);
  Indust_Loans_CH_31   <- BankLoanGCDataNew4(sumDep092008,ChargeOffData092008,LoanData092008,IDRSSD);
  
  #December 31st, 2008
  sumDep122008 <- subset(bankData8,Reporting.Period.End.Date=="12/31/2008")
  ChargeOffData122008 <- read.csv("FFIEC CDR Call Schedule RIBI 12312008.csv",header=TRUE);
  LoanData122008      <- read.csv("FFIEC CDR Call Schedule RCCI 12312008.csv",header=TRUE);
  
  #Indust_Loans_CH_32   <- LoanCharge5a1(sumDep122008,ChargeOffData122008,LoanData122008);
  Indust_Loans_CH_32   <- BankLoanGCDataNew4(sumDep122008,ChargeOffData122008,LoanData122008,IDRSSD);
  
  #2009
  bankData9 <- read.csv("bank_level_data_9a.csv",header=TRUE);
  
  #March 31st, 2009
  #sumDep2 <- subset(bankData2,Reporting.Period.End.Date=="3/31/2002")
  sumDep032009 <- subset(bankData9,Reporting.Period.End.Date=="3/31/2009")
  ChargeOffData032009 <- read.csv("FFIEC CDR Call Schedule RIBI 03312009.csv",header=TRUE);
  LoanData032009      <- read.csv("FFIEC CDR Call Schedule RCCI 03312009.csv",header=TRUE);
  
  #Indust_Loans_CH_33   <- LoanCharge5a1(sumDep032009,ChargeOffData032009,LoanData032009);
  Indust_Loans_CH_33   <- BankLoanGCDataNew4(sumDep032009,ChargeOffData032009,LoanData032009,IDRSSD);
  
  #June 30th, 2009
  sumDep062009        <- subset(bankData9,Reporting.Period.End.Date=="6/30/2009")
  ChargeOffData062009 <- read.csv("FFIEC CDR Call Schedule RIBI 06302009.csv",header=TRUE);
  LoanData062009      <- read.csv("FFIEC CDR Call Schedule RCCI 06302009.csv",header=TRUE);
  
  #Indust_Loans_CH_34   <- LoanCharge5a1(sumDep062009,ChargeOffData062009,LoanData062009);
  Indust_Loans_CH_34   <- BankLoanGCDataNew4(sumDep062009,ChargeOffData062009,LoanData062009,IDRSSD);
  
  #September 30th, 2009
  sumDep092009 <- subset(bankData9,Reporting.Period.End.Date=="9/30/2009")
  ChargeOffData092009 <- read.csv("FFIEC CDR Call Schedule RIBI 09302009.csv",header=TRUE);
  LoanData092009      <- read.csv("FFIEC CDR Call Schedule RCCI 09302009.csv",header=TRUE);
  
  #Indust_Loans_CH_35   <- LoanCharge5a1(sumDep092009,ChargeOffData092009,LoanData092009);
  Indust_Loans_CH_35   <- BankLoanGCDataNew4(sumDep092009,ChargeOffData092009,LoanData092009,IDRSSD);
  
  #December 31st, 2009
  sumDep122009 <- subset(bankData9,Reporting.Period.End.Date=="12/31/2009")
  ChargeOffData122009 <- read.csv("FFIEC CDR Call Schedule RIBI 12312009.csv",header=TRUE);
  LoanData122009      <- read.csv("FFIEC CDR Call Schedule RCCI 12312009.csv",header=TRUE);
  
  #Indust_Loans_CH_36   <- LoanCharge5a1(sumDep122009,ChargeOffData122009,LoanData122009);
  Indust_Loans_CH_36   <- BankLoanGCDataNew4(sumDep122009,ChargeOffData122009,LoanData122009,IDRSSD);
  
  #2010
  bankData10 <- read.csv("bank_level_data_10a.csv",header=TRUE);
  
  #March 31st, 2010
  #sumDep2 <- subset(bankData2,Reporting.Period.End.Date=="3/31/2002")
  sumDep032010         <- subset(bankData10,Reporting.Period.End.Date=="3/31/2010")
  ChargeOffData032010 <- read.csv("FFIEC CDR Call Schedule RIBI 03312010.csv",header=TRUE);
  LoanData032010      <- read.csv("FFIEC CDR Call Schedule RCCI 03312010.csv",header=TRUE);
  
  #Indust_Loans_CH_37   <- LoanCharge6a1(sumDep032010,ChargeOffData032010,LoanData032010);
  Indust_Loans_CH_37   <- BankLoanGCDataNew5(sumDep032010,ChargeOffData032010,LoanData032010,IDRSSD);
  
  #June 30th, 2010
  sumDep062010        <- subset(bankData10,Reporting.Period.End.Date=="6/30/2010")
  ChargeOffData062010 <- read.csv("FFIEC CDR Call Schedule RIBI 06302010.csv",header=TRUE);
  LoanData062010      <- read.csv("FFIEC CDR Call Schedule RCCI 06302010.csv",header=TRUE);
  
  #Indust_Loans_CH_38   <- LoanCharge6a1(sumDep062010,ChargeOffData062010,LoanData062010);
  Indust_Loans_CH_38   <- BankLoanGCDataNew5(sumDep062010,ChargeOffData062010,LoanData062010, IDRSSD);
  
  #September 30th, 2010
  sumDep092010 <- subset(bankData10,Reporting.Period.End.Date=="9/30/2010")
  ChargeOffData092010 <- read.csv("FFIEC CDR Call Schedule RIBI 09302010.csv",header=TRUE);
  LoanData092010      <- read.csv("FFIEC CDR Call Schedule RCCI 09302010.csv",header=TRUE);
  
  #Indust_Loans_CH_39   <- LoanCharge6a1(sumDep092010,ChargeOffData092010,LoanData092010);
  Indust_Loans_CH_39   <- BankLoanGCDataNew5(sumDep092010,ChargeOffData092010,LoanData092010,IDRSSD);
  
  #December 31st, 2010
  sumDep122010 <- subset(bankData10,Reporting.Period.End.Date=="12/31/2010")
  ChargeOffData122010 <- read.csv("FFIEC CDR Call Schedule RIBI 12312010.csv",header=TRUE);
  LoanData122010      <- read.csv("FFIEC CDR Call Schedule RCCI 12312010.csv",header=TRUE);
  
  #Indust_Loans_CH_40   <- LoanCharge6a1(sumDep122010,ChargeOffData122010,LoanData122010);
  Indust_Loans_CH_40   <- BankLoanGCDataNew5(sumDep122010,ChargeOffData122010,LoanData122010, IDRSSD);
  
  #2011
  bankData11 <- read.csv("bank_level_data_11a1.csv",header=TRUE);
  
  #March 31st, 2011
  #sumDep2 <- subset(bankData2,Reporting.Period.End.Date=="3/31/2002")
  sumDep032011         <- subset(bankData11,Reporting.Period.End.Date=="3/31/2011")
  ChargeOffData032011 <- read.csv("FFIEC CDR Call Schedule RIBI 03312011.csv",header=TRUE);
  LoanData032011      <- read.csv("FFIEC CDR Call Schedule RCCI 03312011.csv",header=TRUE);
  
  #Indust_Loans_CH_41   <- LoanCharge7a(sumDep032011,ChargeOffData032011,LoanData032011);
  Indust_Loans_CH_41   <- BankLoanGCDataNew6(sumDep032011,ChargeOffData032011,LoanData032011, IDRSSD);
  
  #June 30th, 2011
  sumDep062011        <- subset(bankData11,Reporting.Period.End.Date=="6/30/2011")
  ChargeOffData062011 <- read.csv("FFIEC CDR Call Schedule RIBI 06302011.csv",header=TRUE);
  LoanData062011      <- read.csv("FFIEC CDR Call Schedule RCCI 06302011.csv",header=TRUE);
  
  #Indust_Loans_CH_42   <- LoanCharge7a(sumDep062011,ChargeOffData062011,LoanData062011);
  Indust_Loans_CH_42   <- BankLoanGCDataNew6(sumDep062011,ChargeOffData062011,LoanData062011,IDRSSD);
  
  #September 30th, 2011
  sumDep092011 <- subset(bankData11,Reporting.Period.End.Date=="9/30/2011")
  ChargeOffData092011 <- read.csv("FFIEC CDR Call Schedule RIBI 09302011.csv",header=TRUE);
  LoanData092011      <- read.csv("FFIEC CDR Call Schedule RCCI 09302011.csv",header=TRUE);
  
  #Indust_Loans_CH_43   <- LoanCharge7a(sumDep092011,ChargeOffData092011,LoanData092011);
  Indust_Loans_CH_43   <- BankLoanGCDataNew6(sumDep092011,ChargeOffData092011,LoanData092011,IDRSSD);
  
  #December 31st, 2011
  sumDep122011 <- subset(bankData11,Reporting.Period.End.Date=="12/31/2011")
  ChargeOffData122011 <- read.csv("FFIEC CDR Call Schedule RIBI 12312011.csv",header=TRUE);
  LoanData122011      <- read.csv("FFIEC CDR Call Schedule RCCI 12312011.csv",header=TRUE);
  
  #Indust_Loans_CH_44   <- LoanCharge7a(sumDep122011,ChargeOffData122011,LoanData122011);
  Indust_Loans_CH_44   <- BankLoanGCDataNew6(sumDep122011,ChargeOffData122011,LoanData122011,IDRSSD);
  
  #2012
  bankData12 <- read.csv("bank_level_data_12a1.csv",header=TRUE);
  
  #March 31st, 2012
  #sumDep2 <- subset(bankData2,Reporting.Period.End.Date=="3/31/2002")
  sumDep032012         <- subset(bankData12,Reporting.Period.End.Date=="3/31/2012")
  ChargeOffData032012 <- read.csv("FFIEC CDR Call Schedule RIBI 03312012.csv",header=TRUE);
  LoanData032012      <- read.csv("FFIEC CDR Call Schedule RCCI 03312012.csv",header=TRUE);
  
  #Indust_Loans_CH_45   <- LoanCharge7a(sumDep032012,ChargeOffData032012,LoanData032012);
  Indust_Loans_CH_45   <- BankLoanGCDataNew6(sumDep032012,ChargeOffData032012,LoanData032012, IDRSSD);
  
  #June 30th, 2012
  sumDep062012        <- subset(bankData12,Reporting.Period.End.Date=="6/30/2012")
  ChargeOffData062012 <- read.csv("FFIEC CDR Call Schedule RIBI 06302012.csv",header=TRUE);
  LoanData062012      <- read.csv("FFIEC CDR Call Schedule RCCI 06302012.csv",header=TRUE);
  
  #Indust_Loans_CH_46   <- LoanCharge7a(sumDep062012,ChargeOffData062012,LoanData062012);
  Indust_Loans_CH_46   <- BankLoanGCDataNew6(sumDep062012,ChargeOffData062012,LoanData062012, IDRSSD);
  
  #September 30th, 2012
  sumDep092012        <- subset(bankData12,Reporting.Period.End.Date=="9/30/2012")
  ChargeOffData092012 <- read.csv("FFIEC CDR Call Schedule RIBI 09302012.csv",header=TRUE);
  LoanData092012      <- read.csv("FFIEC CDR Call Schedule RCCI 09302012.csv",header=TRUE);
  
  #Indust_Loans_CH_47   <- LoanCharge7a(sumDep092012,ChargeOffData092012,LoanData092012);
  Indust_Loans_CH_47   <- BankLoanGCDataNew6(sumDep092012,ChargeOffData092012,LoanData092012, IDRSSD);
  
  #December 31st, 2012
  sumDep122012 <- subset(bankData12,Reporting.Period.End.Date=="12/31/2012")
  ChargeOffData122012 <- read.csv("FFIEC CDR Call Schedule RIBI 12312012.csv",header=TRUE);
  LoanData122012      <- read.csv("FFIEC CDR Call Schedule RCCI 12312012.csv",header=TRUE);
  
  #Indust_Loans_CH_48   <- LoanCharge7a(sumDep122012,ChargeOffData122012,LoanData122012);
  Indust_Loans_CH_48   <- BankLoanGCDataNew6(sumDep122012,ChargeOffData122012,LoanData122012, IDRSSD);
  
  #2013
  bankData13 <- read.csv("bank_level_data_13a1.csv",header=TRUE);
  
  #March 31st, 2013
  #sumDep2 <- subset(bankData2,Reporting.Period.End.Date=="3/31/2012")
  sumDep032013         <- subset(bankData13,Reporting.Period.End.Date=="3/31/2013")
  ChargeOffData032013 <- read.csv("FFIEC CDR Call Schedule RIBI 03312013.csv",header=TRUE);
  LoanData032013      <- read.csv("FFIEC CDR Call Schedule RCCI 03312013.csv",header=TRUE);
  
  #Indust_Loans_CH_49   <- LoanCharge7a(sumDep032013,ChargeOffData032013,LoanData032013);
  Indust_Loans_CH_49   <- BankLoanGCDataNew6(sumDep032013,ChargeOffData032013,LoanData032013, IDRSSD);
  
  #June 30th, 2013
  sumDep062013        <- subset(bankData13,Reporting.Period.End.Date=="6/30/2013")
  ChargeOffData062013 <- read.csv("FFIEC CDR Call Schedule RIBI 06302013.csv",header=TRUE);
  LoanData062013      <- read.csv("FFIEC CDR Call Schedule RCCI 06302013.csv",header=TRUE);
  
  #Indust_Loans_CH_50   <- LoanCharge7a(sumDep062013,ChargeOffData062013,LoanData062013);
  Indust_Loans_CH_50   <- BankLoanGCDataNew6(sumDep062013,ChargeOffData062013,LoanData062013, IDRSSD);
  
  #September 30th, 2013
  sumDep092013        <- subset(bankData13,Reporting.Period.End.Date=="9/30/2013")
  ChargeOffData092013 <- read.csv("FFIEC CDR Call Schedule RIBI 09302013.csv",header=TRUE);
  LoanData092013      <- read.csv("FFIEC CDR Call Schedule RCCI 09302013.csv",header=TRUE);
  
  #Indust_Loans_CH_51   <- LoanCharge7a(sumDep092013,ChargeOffData092013,LoanData092013);
  Indust_Loans_CH_51   <- BankLoanGCDataNew6(sumDep092013,ChargeOffData092013,LoanData092013, IDRSSD);
  
  #December 31st, 2013
  sumDep122013 <- subset(bankData13,Reporting.Period.End.Date=="12/31/2013")
  ChargeOffData122013 <- read.csv("FFIEC CDR Call Schedule RIBI 12312013.csv",header=TRUE);
  LoanData122013      <- read.csv("FFIEC CDR Call Schedule RCCI 12312013.csv",header=TRUE);
  
  #Indust_Loans_CH_52   <- LoanCharge7a(sumDep122013,ChargeOffData122013,LoanData122013);
  Indust_Loans_CH_52   <- BankLoanGCDataNew6(sumDep122013,ChargeOffData122013,LoanData122013, IDRSSD);
  
  #2014
  bankData14 <- read.csv("bank_level_data_14a1.csv",header=TRUE);
  
  #March 31st, 2014
  #sumDep2 <- subset(bankData2,Reporting.Period.End.Date=="3/31/2012")
  sumDep032014        <- subset(bankData14,Reporting.Period.End.Date=="3/31/2014")
  ChargeOffData032014 <- read.csv("FFIEC CDR Call Schedule RIBI 03312014.csv",header=TRUE);
  LoanData032014      <- read.csv("FFIEC CDR Call Schedule RCCI 03312014.csv",header=TRUE);
  
  #Indust_Loans_CH_53  <- LoanCharge7a(sumDep032014,ChargeOffData032014,LoanData032014);
  Indust_Loans_CH_53  <- BankLoanGCDataNew6(sumDep032014,ChargeOffData032014,LoanData032014, IDRSSD);
  
  #June 30th, 2014
  sumDep062014        <- subset(bankData14,Reporting.Period.End.Date=="6/30/2014")
  ChargeOffData062014 <- read.csv("FFIEC CDR Call Schedule RIBI 06302014.csv",header=TRUE);
  LoanData062014      <- read.csv("FFIEC CDR Call Schedule RCCI 06302014.csv",header=TRUE);
  
  #Indust_Loans_CH_54   <- LoanCharge7a(sumDep062014,ChargeOffData062014,LoanData062014);
  Indust_Loans_CH_54   <- BankLoanGCDataNew6(sumDep062014,ChargeOffData062014,LoanData062014, IDRSSD);
  
  #September 30th, 2014
  sumDep092014        <- subset(bankData14,Reporting.Period.End.Date=="9/30/2014")
  ChargeOffData092014 <- read.csv("FFIEC CDR Call Schedule RIBI 09302014.csv",header=TRUE);
  LoanData092014      <- read.csv("FFIEC CDR Call Schedule RCCI 09302014.csv",header=TRUE);
  
  #Indust_Loans_CH_55   <- LoanCharge7a(sumDep092014,ChargeOffData092014,LoanData092014);
  Indust_Loans_CH_55   <- BankLoanGCDataNew6(sumDep092014,ChargeOffData092014,LoanData092014, IDRSSD);
  
  #December 31st, 2014
  sumDep122014 <- subset(bankData14,Reporting.Period.End.Date=="12/31/2014")
  ChargeOffData122014 <- read.csv("FFIEC CDR Call Schedule RIBI 12312014.csv",header=TRUE);
  LoanData122014      <- read.csv("FFIEC CDR Call Schedule RCCI 12312014.csv",header=TRUE);
  
  #Indust_Loans_CH_56   <- LoanCharge7a(sumDep122014,ChargeOffData122014,LoanData122014);
  Indust_Loans_CH_56   <- BankLoanGCDataNew6(sumDep122014,ChargeOffData122014,LoanData122014, IDRSSD);
  
  
  #2015
  bankData15 <- read.csv("bank_level_data_15a1.csv",header=TRUE);
  
  #March 31st, 2015
  #sumDep2 <- subset(bankData2,Reporting.Period.End.Date=="3/31/2012")
  sumDep032015         <- subset(bankData15,Reporting.Period.End.Date=="3/31/2015")
  ChargeOffData032015  <- read.csv("FFIEC CDR Call Schedule RIBI 03312015.csv",header=TRUE);
  LoanData032015       <- read.csv("FFIEC CDR Call Schedule RCCI 03312015.csv",header=TRUE);
  
  #Indust_Loans_CH_57   <- LoanCharge7a(sumDep032015,ChargeOffData032015,LoanData032015);
  Indust_Loans_CH_57   <- BankLoanGCDataNew6(sumDep032015,ChargeOffData032015,LoanData032015,IDRSSD);
  
  #June 30th, 2015
  sumDep062015        <- subset(bankData15,Reporting.Period.End.Date=="6/30/2015")
  ChargeOffData062015 <- read.csv("FFIEC CDR Call Schedule RIBI 06302015.csv",header=TRUE);
  LoanData062015      <- read.csv("FFIEC CDR Call Schedule RCCI 06302015.csv",header=TRUE);
  
  #Indust_Loans_CH_58   <- LoanCharge7a(sumDep062015,ChargeOffData062015,LoanData062015);
  Indust_Loans_CH_58   <- BankLoanGCDataNew6(sumDep062015,ChargeOffData062015,LoanData062015, IDRSSD);
  
  #September 30th, 2015
  sumDep092015        <- subset(bankData15,Reporting.Period.End.Date=="9/30/2015")
  ChargeOffData092015 <- read.csv("FFIEC CDR Call Schedule RIBI 09302015.csv",header=TRUE);
  LoanData092015      <- read.csv("FFIEC CDR Call Schedule RCCI 09302015.csv",header=TRUE);
  
  #Indust_Loans_CH_59   <- LoanCharge7a(sumDep092015,ChargeOffData092015,LoanData092015);
  Indust_Loans_CH_59   <- BankLoanGCDataNew6(sumDep092015,ChargeOffData092015, LoanData092015, IDRSSD);
  
  #December 31st, 2015
  sumDep122015 <- subset(bankData15,Reporting.Period.End.Date=="12/31/2015")
  ChargeOffData122015 <- read.csv("FFIEC CDR Call Schedule RIBI 12312015.csv",header=TRUE);
  LoanData122015      <- read.csv("FFIEC CDR Call Schedule RCCI 12312015.csv",header=TRUE);
  
  #Indust_Loans_CH_60   <- LoanCharge7a(sumDep122015,ChargeOffData122015,LoanData122015);
  Indust_Loans_CH_60   <- BankLoanGCDataNew6(sumDep122015,ChargeOffData122015,LoanData122015, IDRSSD);
  
  #2016
  bankData16 <- read.csv("bank_level_data_16a.csv",header=TRUE);
  
  #March 31st, 2016
  #sumDep2 <- subset(bankData2,Reporting.Period.End.Date=="3/31/2016")
  sumDep032016         <- subset(bankData16,Reporting.Period.End.Date=="3/31/2016")
  ChargeOffData032016  <- read.csv("FFIEC CDR Call Schedule RIBI 03312016.csv",header=TRUE);
  LoanData032016       <- read.csv("FFIEC CDR Call Schedule RCCI 03312016.csv",header=TRUE);
  
  #Indust_Loans_CH_61  <- LoanCharge7a(sumDep032016,ChargeOffData032016,LoanData032016);
  
  Indust_Loans_CH_61  <- BankLoanGCDataNew6(sumDep032016,ChargeOffData032016,LoanData032016, IDRSSD);
  
  #June 30th, 2016
  sumDep062016        <- subset(bankData16,Reporting.Period.End.Date=="6/30/2016")
  ChargeOffData062016 <- read.csv("FFIEC CDR Call Schedule RIBI 06302016.csv",header=TRUE);
  LoanData062016     <- read.csv("FFIEC CDR Call Schedule RCCI 06302016.csv",header=TRUE);
  
  #Indust_Loans_CH_62   <- LoanCharge7a(sumDep062016,ChargeOffData062016,LoanData062016);
  
  Indust_Loans_CH_62   <- BankLoanGCDataNew6(sumDep062016,ChargeOffData062016,LoanData062016,IDRSSD)
  
  #Now, stitch the data into a time-series
  
  CompareChargeOffRates <- data.frame(rbind(NewJack, (Indust_Loans_CH_24),(Indust_Loans_CH_25),(Indust_Loans_CH_26),(Indust_Loans_CH_27),
                                            (Indust_Loans_CH_28),(Indust_Loans_CH_29),(Indust_Loans_CH_30),(Indust_Loans_CH_31), (Indust_Loans_CH_32),
                                            (Indust_Loans_CH_33),(Indust_Loans_CH_34),(Indust_Loans_CH_35),
                                            (Indust_Loans_CH_36),(Indust_Loans_CH_37),(Indust_Loans_CH_38),(Indust_Loans_CH_39),
                                            (Indust_Loans_CH_40),(Indust_Loans_CH_41),(Indust_Loans_CH_42),(Indust_Loans_CH_43),
                                            (Indust_Loans_CH_44),(Indust_Loans_CH_45),(Indust_Loans_CH_46),(Indust_Loans_CH_47),
                                            (Indust_Loans_CH_48),(Indust_Loans_CH_49),(Indust_Loans_CH_50),(Indust_Loans_CH_51),
                                            (Indust_Loans_CH_52),(Indust_Loans_CH_53),(Indust_Loans_CH_54),(Indust_Loans_CH_55),
                                            (Indust_Loans_CH_56),(Indust_Loans_CH_57),(Indust_Loans_CH_58),(Indust_Loans_CH_59),
                                            (Indust_Loans_CH_60),(Indust_Loans_CH_61),(Indust_Loans_CH_62)));
  
  #CompareChargeOffRates <- rbind(CompareChargeOffRates,(Indust_Loans_CH_5),(Indust_Loans_CH_6),(Indust_Loans_CH_7),
  #                               (Indust_Loans_CH_8),(Indust_Loans_CH_9),(Indust_Loans_CH_10),(Indust_Loans_CH_11));
  #,(Indust_Loans_CH_12),(Indust_Loans_CH_13),(Indust_Loans_CH_14),(Indust_Loans_CH_15),
  #(Indust_Loans_CH_16),(Indust_Loans_CH_17),(Indust_Loans_CH_18),(Indust_Loans_CH_19),
  #(Indust_Loans_CH_20),(Indust_Loans_CH_21),(Indust_Loans_CH_22),(Indust_Loans_CH_23),
  #(Indust_Loans_CH_24),(Indust_Loans_CH_25),(Indust_Loans_CH_26),(Indust_Loans_CH_27),
  #(Indust_Loans_CH_28),(Indust_Loans_CH_29),(Indust_Loans_CH_30),(Indust_Loans_CH_31),
  #(Indust_Loans_CH_32),(Indust_Loans_CH_33),(Indust_Loans_CH_34),(Indust_Loans_CH_35),
  #(Indust_Loans_CH_36),(Indust_Loans_CH_37),(Indust_Loans_CH_38),(Indust_Loans_CH_39),
  #(Indust_Loans_CH_40),(Indust_Loans_CH_41),(Indust_Loans_CH_42),(Indust_Loans_CH_43),
  #(Indust_Loans_CH_44),(Indust_Loans_CH_45),(Indust_Loans_CH_46),(Indust_Loans_CH_47),
  #(Indust_Loans_CH_48),(Indust_Loans_CH_49),(Indust_Loans_CH_50),(Indust_Loans_CH_51),
  #(Indust_Loans_CH_52),(Indust_Loans_CH_53),(Indust_Loans_CH_54),(Indust_Loans_CH_55),
  #(Indust_Loans_CH_56),(Indust_Loans_CH_57),(Indust_Loans_CH_58),(Indust_Loans_CH_59),
  #(Indust_Loans_CH_60),(Indust_Loans_CH_61),(Indust_Loans_CH_62));
  
  
  return(CompareChargeOffRates)
}