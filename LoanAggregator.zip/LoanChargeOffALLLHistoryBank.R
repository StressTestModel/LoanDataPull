LoanChargeOffALLLHistoryBank <- function (IDRSSD) {
  #Write a function to generate time-series data for individual banks - Loan and Charge-Off Data as well as Charge-Off Rates
  
  #Pre-load the data#Use this dataset to identify largest 50 banks
  #bankData <- read.csv("bank_level_data_1a.csv",header=TRUE);
  #Load Call data with balance sheet information
  #March 31st, 2001
  #sumDep032001 <- subset(bankData,Reporting.Period.End.Date=="3/31/2001")
  ALLLData032001 <- read.csv("FFIEC CDR Call Schedule RIBII 03312001.csv",header=TRUE);
  ChargeOffData032001 <- read.csv("FFIEC CDR Call Schedule RIBI 03312001.csv",header=TRUE);
  LoanData032001      <- read.csv("FFIEC CDR Call Schedule RCCI 03312001.csv",header=TRUE);
  
  #Indust_Loans_CH_1 <- LoanChargea(sumDep032001, ChargeOffData032001, LoanData032001);
  Indust_Loans_CH_1 <- BankData_LossesLoans1(ALLLData032001,ChargeOffData032001, LoanData032001,IDRSSD);
  
  #June 30th, 2001
  #sumDep062001 <- subset(bankData,Reporting.Period.End.Date=="6/30/2001")
  ALLLData062001 <- read.csv("FFIEC CDR Call Schedule RIBII 06302001.csv",header=TRUE);
  ChargeOffData062001 <- read.csv("FFIEC CDR Call Schedule RIBI 06302001.csv",header=TRUE);
  LoanData062001      <- read.csv("FFIEC CDR Call Schedule RCCI 06302001.csv",header=TRUE);
  
  #Indust_Loans_CH_2   <- LoanChargea(sumDep062001,ChargeOffData062001,LoanData062001);
  Indust_Loans_CH_2   <- BankData_LossesLoans2(ALLLData062001, ChargeOffData062001,LoanData062001,IDRSSD);
  
  #September 30th, 2001
  #sumDep092001 <- subset(bankData,Reporting.Period.End.Date=="9/30/2001")
  ALLLData092001 <- read.csv("FFIEC CDR Call Schedule RIBII 09302001.csv",header=TRUE);
  ChargeOffData092001 <- read.csv("FFIEC CDR Call Schedule RIBI 09302001.csv",header=TRUE);
  LoanData092001      <- read.csv("FFIEC CDR Call Schedule RCCI 09302001.csv",header=TRUE);
  
  #Indust_Loans_CH_3   <- LoanChargea(sumDep092001,ChargeOffData092001,LoanData092001);
  Indust_Loans_CH_3   <- BankData_LossesLoans2(ALLLData092001,ChargeOffData092001,LoanData092001,IDRSSD);
  
  #December 31st, 2001
  #sumDep122001 <- subset(bankData,Reporting.Period.End.Date=="12/31/2001")
  ALLLData122001 <- read.csv("FFIEC CDR Call Schedule RIBII 12312001.csv",header=TRUE);
  ChargeOffData122001 <- read.csv("FFIEC CDR Call Schedule RIBI 12312001.csv",header=TRUE);
  LoanData122001      <- read.csv("FFIEC CDR Call Schedule RCCI 12312001.csv",header=TRUE);
  
  #Indust_Loans_CH_4   <- LoanChargea(sumDep122001,ChargeOffData122001,LoanData122001);
  Indust_Loans_CH_4   <- BankData_LossesLoans2(ALLLData122001,ChargeOffData122001,LoanData122001,IDRSSD);
  
  
  #2002
  #bankData2 <- read.csv("bank_level_data_2a.csv",header=TRUE);
  
  #March 31st, 2002
  #sumDep2 <- subset(bankData2,Reporting.Period.End.Date=="3/31/2002")
  #sumDep032002 <- subset(bankData2,Reporting.Period.End.Date=="3/31/2002")
  ALLLData032002 <- read.csv("FFIEC CDR Call Schedule RIBII 03312002.csv",header=TRUE);
  ChargeOffData032002 <- read.csv("FFIEC CDR Call Schedule RIBI 03312002.csv",header=TRUE);
  LoanData032002      <- read.csv("FFIEC CDR Call Schedule RCCI 03312002.csv",header=TRUE);
  
  #Indust_Loans_CH_5   <- LoanCharge2a(sumDep032002,ChargeOffData032002,LoanData032002);
  Indust_Loans_CH_5   <- BankData_LossesLoans3(ALLLData032002,ChargeOffData032002,LoanData032002,IDRSSD);
  
  #June 30th, 2002
  #sumDep062002        <- subset(bankData2,Reporting.Period.End.Date=="6/30/2002")
  ALLLData062002      <- read.csv("FFIEC CDR Call Schedule RIBII 06302002.csv",header=TRUE);
  ChargeOffData062002 <- read.csv("FFIEC CDR Call Schedule RIBI 06302002.csv",header=TRUE);
  LoanData062002      <- read.csv("FFIEC CDR Call Schedule RCCI 06302002.csv",header=TRUE);
  
  #Indust_Loans_CH_6   <- LoanCharge2a(sumDep062002,ChargeOffData062002,LoanData062002);
  Indust_Loans_CH_6   <- BankData_LossesLoans3(ALLLData062002,ChargeOffData062002,LoanData062002,IDRSSD);
  
  #September 30th, 2002
  #sumDep092002 <- subset(bankData2,Reporting.Period.End.Date=="9/30/2002")
  ALLLData092002      <- read.csv("FFIEC CDR Call Schedule RIBII 09302002.csv",header=TRUE);
  ChargeOffData092002 <- read.csv("FFIEC CDR Call Schedule RIBI 09302002.csv",header=TRUE);
  LoanData092002      <- read.csv("FFIEC CDR Call Schedule RCCI 09302002.csv",header=TRUE);
  
  #Indust_Loans_CH_7   <- LoanCharge2a(sumDep092002,ChargeOffData092002,LoanData092002);
  Indust_Loans_CH_7   <- BankData_LossesLoans3(ALLLData092002,ChargeOffData092002,LoanData092002,IDRSSD);
  
  #December 31st, 2002
  #sumDep122002 <- subset(bankData2,Reporting.Period.End.Date=="12/31/2002")
  ALLLData122002      <- read.csv("FFIEC CDR Call Schedule RIBII 12312002.csv",header=TRUE);
  ChargeOffData122002 <- read.csv("FFIEC CDR Call Schedule RIBI 12312002.csv",header=TRUE);
  LoanData122002      <- read.csv("FFIEC CDR Call Schedule RCCI 12312002.csv",header=TRUE);
  
  #Indust_Loans_CH_8   <- LoanCharge2a(sumDep122002,ChargeOffData122002,LoanData122002);
  Indust_Loans_CH_8   <- BankData_LossesLoans3(ALLLData122002,ChargeOffData122002,LoanData122002,IDRSSD);
  
  #2003
  #bankData3 <- read.csv("bank_level_data_3a.csv",header=TRUE);
  
  #March 31st, 2003
  #sumDep2 <- subset(bankData2,Reporting.Period.End.Date=="3/31/2002")
  #sumDep032003 <- subset(bankData3,Reporting.Period.End.Date=="3/31/2003")
  ALLLData032003      <- read.csv("FFIEC CDR Call Schedule RIBII 03312003.csv",header=TRUE);
  ChargeOffData032003 <- read.csv("FFIEC CDR Call Schedule RIBI 03312003.csv",header=TRUE);
  LoanData032003      <- read.csv("FFIEC CDR Call Schedule RCCI 03312003.csv",header=TRUE);
  
  #Indust_Loans_CH_9   <- LoanCharge2a(sumDep032003,ChargeOffData032003,LoanData032003);
  Indust_Loans_CH_9   <- BankData_LossesLoans3(ALLLData032003,ChargeOffData032003,LoanData032003,IDRSSD);
  
  #June 30th, 2003
  #sumDep062003        <- subset(bankData3,Reporting.Period.End.Date=="6/30/2003")
  ALLLData062003      <- read.csv("FFIEC CDR Call Schedule RIBII 06302003.csv",header=TRUE);
  ChargeOffData062003 <- read.csv("FFIEC CDR Call Schedule RIBI 06302003.csv",header=TRUE);
  LoanData062003      <- read.csv("FFIEC CDR Call Schedule RCCI 06302003.csv",header=TRUE);
  
  #Indust_Loans_CH_10   <- LoanCharge2a(sumDep062003,ChargeOffData062003,LoanData062003);
  Indust_Loans_CH_10   <- BankData_LossesLoans3(ALLLData062003,ChargeOffData062003,LoanData062003,IDRSSD);
  
  #September 30th, 2003
  #sumDep092003 <- subset(bankData3,Reporting.Period.End.Date=="9/30/2003")
  ALLLData092003 <- read.csv("FFIEC CDR Call Schedule RIBII 09302003.csv",header=TRUE);
  ChargeOffData092003 <- read.csv("FFIEC CDR Call Schedule RIBI 09302003.csv",header=TRUE);
  LoanData092003      <- read.csv("FFIEC CDR Call Schedule RCCI 09302003.csv",header=TRUE);
  
  #Indust_Loans_CH_11   <- LoanCharge2a(sumDep092003,ChargeOffData092003,LoanData092003);
  Indust_Loans_CH_11   <- BankData_LossesLoans3(ALLLData092003,ChargeOffData092003,LoanData092003,IDRSSD);
  
  #December 31st, 2003
  #sumDep122003 <- subset(bankData3,Reporting.Period.End.Date=="12/31/2003")
  ALLLData122003 <- read.csv("FFIEC CDR Call Schedule RIBII 12312003.csv",header=TRUE);
  ChargeOffData122003 <- read.csv("FFIEC CDR Call Schedule RIBI 12312003.csv",header=TRUE);
  LoanData122003      <- read.csv("FFIEC CDR Call Schedule RCCI 12312003.csv",header=TRUE);
  
  #Indust_Loans_CH_12   <- LoanCharge2a(sumDep122003,ChargeOffData122003,LoanData122003);
  Indust_Loans_CH_12   <- BankData_LossesLoans3(ALLLData122003,ChargeOffData122003,LoanData122003,IDRSSD);
  
  
  #2004
  #bankData4 <- read.csv("bank_level_data_4a.csv",header=TRUE);
  
  #March 31st, 2004
  #sumDep2 <- subset(bankData2,Reporting.Period.End.Date=="3/31/2002")
  #sumDep032004 <- subset(bankData4,Reporting.Period.End.Date=="3/31/2004")
  ALLLData032004 <- read.csv("FFIEC CDR Call Schedule RIBII 03312004.csv",header=TRUE);
  ChargeOffData032004 <- read.csv("FFIEC CDR Call Schedule RIBI 03312004.csv",header=TRUE);
  LoanData032004      <- read.csv("FFIEC CDR Call Schedule RCCI 03312004.csv",header=TRUE);
  
  #Indust_Loans_CH_13   <- LoanCharge2a(sumDep032004,ChargeOffData032004,LoanData032004);
  Indust_Loans_CH_13   <- BankData_LossesLoans3(ALLLData032004,ChargeOffData032004,LoanData032004,IDRSSD);
  
  #June 30th, 2004
  #sumDep062004        <- subset(bankData4,Reporting.Period.End.Date=="6/30/2004")
  ALLLData062004 <- read.csv("FFIEC CDR Call Schedule RIBII 06302004.csv",header=TRUE);
  ChargeOffData062004 <- read.csv("FFIEC CDR Call Schedule RIBI 06302004.csv",header=TRUE);
  LoanData062004      <- read.csv("FFIEC CDR Call Schedule RCCI 06302004.csv",header=TRUE);
  
  #Indust_Loans_CH_14   <- LoanCharge2a(sumDep062004,ChargeOffData062004,LoanData062004);
  Indust_Loans_CH_14   <- BankData_LossesLoans3(ALLLData062004,ChargeOffData062004,LoanData062004,IDRSSD);
  
  #September 30th, 2004
  #sumDep092004 <- subset(bankData4,Reporting.Period.End.Date=="9/30/2004")
  ALLLData092004 <- read.csv("FFIEC CDR Call Schedule RIBII 09302004.csv",header=TRUE);
  ChargeOffData092004 <- read.csv("FFIEC CDR Call Schedule RIBI 09302004.csv",header=TRUE);
  LoanData092004      <- read.csv("FFIEC CDR Call Schedule RCCI 09302004.csv",header=TRUE);
  
  #Indust_Loans_CH_15   <- LoanCharge2a(sumDep092004,ChargeOffData092004,LoanData092004);
  Indust_Loans_CH_15   <- BankData_LossesLoans3(ALLLData092004,ChargeOffData092004,LoanData092004,IDRSSD);
  
  #December 31st, 2004
  #sumDep122004 <- subset(bankData4,Reporting.Period.End.Date=="12/31/2004")
  ALLLData122004 <- read.csv("FFIEC CDR Call Schedule RIBII 12312004.csv",header=TRUE);
  ChargeOffData122004 <- read.csv("FFIEC CDR Call Schedule RIBI 12312004.csv",header=TRUE);
  LoanData122004      <- read.csv("FFIEC CDR Call Schedule RCCI 12312004.csv",header=TRUE);
  
  #Indust_Loans_CH_16   <- LoanCharge2a(sumDep122004,ChargeOffData122004,LoanData122004);
  Indust_Loans_CH_16   <- BankData_LossesLoans3(ALLLData122004,ChargeOffData122004,LoanData122004,IDRSSD);
  
  #2005
  #bankData5 <- read.csv("bank_level_data_5a.csv",header=TRUE);
  
  #March 31st, 2005
  #sumDep2 <- subset(bankData2,Reporting.Period.End.Date=="3/31/2002")
  #sumDep032005 <- subset(bankData5,Reporting.Period.End.Date=="3/31/2005")
  ALLLData032005 <- read.csv("FFIEC CDR Call Schedule RIBII 03312005.csv",header=TRUE);
  ChargeOffData032005 <- read.csv("FFIEC CDR Call Schedule RIBI 03312005.csv",header=TRUE);
  LoanData032005      <- read.csv("FFIEC CDR Call Schedule RCCI 03312005.csv",header=TRUE);
  
  #Indust_Loans_CH_17   <- LoanCharge2a(sumDep032005,ChargeOffData032005,LoanData032005);
  Indust_Loans_CH_17   <- BankData_LossesLoans3(ALLLData032005,ChargeOffData032005,LoanData032005,IDRSSD);
  
  #June 30th, 2005
  #sumDep062005        <- subset(bankData5,Reporting.Period.End.Date=="6/30/2005")
  ALLLData062005 <- read.csv("FFIEC CDR Call Schedule RIBII 06302005.csv",header=TRUE);
  ChargeOffData062005 <- read.csv("FFIEC CDR Call Schedule RIBI 06302005.csv",header=TRUE);
  LoanData062005      <- read.csv("FFIEC CDR Call Schedule RCCI 06302005.csv",header=TRUE);
  
  #Indust_Loans_CH_18   <- LoanCharge2a(sumDep062005,ChargeOffData062005,LoanData062005);
  Indust_Loans_CH_18   <- BankData_LossesLoans3(ALLLData062005,ChargeOffData062005,LoanData062005,IDRSSD);
  
  #September 30th, 2005
  #sumDep092005 <- subset(bankData5,Reporting.Period.End.Date=="9/30/2005")
  ALLLData092005 <- read.csv("FFIEC CDR Call Schedule RIBII 09302005.csv",header=TRUE);
  ChargeOffData092005 <- read.csv("FFIEC CDR Call Schedule RIBI 09302005.csv",header=TRUE);
  LoanData092005      <- read.csv("FFIEC CDR Call Schedule RCCI 09302005.csv",header=TRUE);
  
  #Indust_Loans_CH_19   <- LoanCharge2a(sumDep092005,ChargeOffData092005,LoanData092005);
  Indust_Loans_CH_19   <- BankData_LossesLoans3(ALLLData092005,ChargeOffData092005,LoanData092005,IDRSSD);
  
  #December 31st, 2005 %CHECK FOR ERRORS - Done!!
  #sumDep122005        <- subset(bankData5,Reporting.Period.End.Date=="12/31/2005")
  ALLLData122005 <- read.csv("FFIEC CDR Call Schedule RIBII 12312005.csv",header=TRUE);
  ChargeOffData122005 <- read.csv("FFIEC CDR Call Schedule RIBI 12312005.csv",header=TRUE);
  LoanData122005      <- read.csv("FFIEC CDR Call Schedule RCCI 12312005.csv",header=TRUE);
  
  #Indust_Loans_CH_20   <- LoanCharge2a(sumDep122005,ChargeOffData122005,LoanData122005);
  Indust_Loans_CH_20   <- BankData_LossesLoans3(ALLLData122005,ChargeOffData122005,LoanData122005,IDRSSD);
  
  
  #2006
  #bankData6 <- read.csv("bank_level_data_6a.csv",header=TRUE);
  
  #March 31st, 2006
  #sumDep2 <- subset(bankData2,Reporting.Period.End.Date=="3/31/2002")
  #sumDep032006 <- subset(bankData6,Reporting.Period.End.Date=="3/31/2006")
  ALLLData032006 <- read.csv("FFIEC CDR Call Schedule RIBII 03312006.csv",header=TRUE);
  ChargeOffData032006 <- read.csv("FFIEC CDR Call Schedule RIBI 03312006.csv",header=TRUE);
  LoanData032006      <- read.csv("FFIEC CDR Call Schedule RCCI 03312006.csv",header=TRUE);
  
  #Indust_Loans_CH_21   <- LoanCharge2a(sumDep032006,ChargeOffData032006,LoanData032006);
  Indust_Loans_CH_21   <- BankData_LossesLoans3(ALLLData032006,ChargeOffData032006,LoanData032006,IDRSSD);
  
  #June 30th, 2006
  #sumDep062006        <- subset(bankData6,Reporting.Period.End.Date=="6/30/2006")
  ALLLData062006 <- read.csv("FFIEC CDR Call Schedule RIBII 06302006.csv",header=TRUE);
  ChargeOffData062006 <- read.csv("FFIEC CDR Call Schedule RIBI 06302006.csv",header=TRUE);
  LoanData062006      <- read.csv("FFIEC CDR Call Schedule RCCI 06302006.csv",header=TRUE);
  
  #Indust_Loans_CH_22   <- LoanCharge2a(sumDep062006,ChargeOffData062006,LoanData062006);
  Indust_Loans_CH_22   <- BankData_LossesLoans3(ALLLData062006,ChargeOffData062006,LoanData062006,IDRSSD);
  
  #September 30th, 2006
  #sumDep092006 <- subset(bankData6,Reporting.Period.End.Date=="9/30/2006")
  ALLLData092006 <- read.csv("FFIEC CDR Call Schedule RIBII 09302006.csv",header=TRUE);
  ChargeOffData092006 <- read.csv("FFIEC CDR Call Schedule RIBI 09302006.csv",header=TRUE);
  LoanData092006      <- read.csv("FFIEC CDR Call Schedule RCCI 09302006.csv",header=TRUE);
  
  #Indust_Loans_CH_23   <- LoanCharge2a(sumDep092006,ChargeOffData092006,LoanData092006);
  Indust_Loans_CH_23   <- BankData_LossesLoans3(ALLLData092006,ChargeOffData092006,LoanData092006,IDRSSD);
  
  #December 31st, 2006
  #sumDep122006 <- subset(bankData6,Reporting.Period.End.Date=="12/31/2006")
  ALLLData122006      <- read.csv("FFIEC CDR Call Schedule RIBII 12312006.csv",header=TRUE);
  ChargeOffData122006 <- read.csv("FFIEC CDR Call Schedule RIBI 12312006.csv",header=TRUE);
  LoanData122006      <- read.csv("FFIEC CDR Call Schedule RCCI 12312006.csv",header=TRUE);
  
  #Indust_Loans_CH_24   <- LoanCharge2a(sumDep122006,ChargeOffData122006,LoanData122006);
  Indust_Loans_CH_24   <- BankData_LossesLoans3(ALLLData122006,ChargeOffData122006,LoanData122006,IDRSSD);
  
  #2007
  #bankData7 <- read.csv("bank_level_data_7a.csv",header=TRUE);
  
  #March 31st, 2007
  #sumDep2 <- subset(bankData2,Reporting.Period.End.Date=="3/31/2002")
  #sumDep032007 <- subset(bankData7,Reporting.Period.End.Date=="3/31/2007")
  ALLLData032007 <- read.csv("FFIEC CDR Call Schedule RIBII 03312007.csv",header=TRUE);
  ChargeOffData032007 <- read.csv("FFIEC CDR Call Schedule RIBI 03312007.csv",header=TRUE);
  LoanData032007      <- read.csv("FFIEC CDR Call Schedule RCCI 03312007.csv",header=TRUE);
  
  #Indust_Loans_CH_25   <- LoanCharge4a(sumDep032007,ChargeOffData032007,LoanData032007);
  Indust_Loans_CH_25   <- BankData_LossesLoans4(ALLLData032007,ChargeOffData032007,LoanData032007,IDRSSD);
  
  #June 30th, 2007
  #sumDep062007        <- subset(bankData7,Reporting.Period.End.Date=="6/30/2007")
  ALLLData062007 <- read.csv("FFIEC CDR Call Schedule RIBII 06302007.csv",header=TRUE);
  ChargeOffData062007 <- read.csv("FFIEC CDR Call Schedule RIBI 06302007.csv",header=TRUE);
  LoanData062007      <- read.csv("FFIEC CDR Call Schedule RCCI 06302007.csv",header=TRUE);
  
  #Indust_Loans_CH_26   <- LoanCharge4a(sumDep062007,ChargeOffData062007,LoanData062007);
  Indust_Loans_CH_26   <- BankData_LossesLoans4(ALLLData062007,ChargeOffData062007,LoanData062007,IDRSSD);
  
  #September 30th, 2007
  #sumDep092007 <- subset(bankData7,Reporting.Period.End.Date=="9/30/2007")
  ALLLData092007 <- read.csv("FFIEC CDR Call Schedule RIBII 09302007.csv",header=TRUE);
  ChargeOffData092007 <- read.csv("FFIEC CDR Call Schedule RIBI 09302007.csv",header=TRUE);
  LoanData092007      <- read.csv("FFIEC CDR Call Schedule RCCI 09302007.csv",header=TRUE);
  
  #Indust_Loans_CH_27   <- LoanCharge4a(sumDep092007,ChargeOffData092007,LoanData092007);
  Indust_Loans_CH_27   <- BankData_LossesLoans4(ALLLData062007,ChargeOffData092007,LoanData092007,IDRSSD);
  
  #December 31st, 2007
  #sumDep122007 <- subset(bankData7,Reporting.Period.End.Date=="12/31/2007")
  ALLLData122007 <- read.csv("FFIEC CDR Call Schedule RIBII 12312007.csv",header=TRUE);
  ChargeOffData122007 <- read.csv("FFIEC CDR Call Schedule RIBI 12312007.csv",header=TRUE);
  LoanData122007      <- read.csv("FFIEC CDR Call Schedule RCCI 12312007.csv",header=TRUE);
  
  #Indust_Loans_CH_28   <- LoanCharge4a(sumDep122007,ChargeOffData122007,LoanData122007);
  Indust_Loans_CH_28   <- BankData_LossesLoans4(ALLLData092007,ChargeOffData122007,LoanData122007,IDRSSD);
  
  #2008
  #bankData8 <- read.csv("bank_level_data_8a.csv",header=TRUE);
  
  #March 31st, 2008
  #sumDep2 <- subset(bankData2,Reporting.Period.End.Date=="3/31/2002")
  #sumDep032008 <- subset(bankData8,Reporting.Period.End.Date=="3/31/2008")
  ALLLData032008 <- read.csv("FFIEC CDR Call Schedule RIBII 03312008.csv",header=TRUE);
  ChargeOffData032008 <- read.csv("FFIEC CDR Call Schedule RIBI 03312008.csv",header=TRUE);
  LoanData032008      <- read.csv("FFIEC CDR Call Schedule RCCI 03312008.csv",header=TRUE);
  
  #Indust_Loans_CH_29   <- LoanCharge5a1(sumDep032008,ChargeOffData032008,LoanData032008);
  Indust_Loans_CH_29   <- BankData_LossesLoans5(ALLLData032008,ChargeOffData032008,LoanData032008,IDRSSD);
  
  #June 30th, 2008
  #sumDep062008        <- subset(bankData8,Reporting.Period.End.Date=="6/30/2008")
  ALLLData062008 <- read.csv("FFIEC CDR Call Schedule RIBII 06302008.csv",header=TRUE);
  ChargeOffData062008 <- read.csv("FFIEC CDR Call Schedule RIBI 06302008.csv",header=TRUE);
  LoanData062008      <- read.csv("FFIEC CDR Call Schedule RCCI 06302008.csv",header=TRUE);
  
  #Indust_Loans_CH_30   <- LoanCharge5a1(sumDep062008,ChargeOffData062008,LoanData062008);
  Indust_Loans_CH_30   <- BankData_LossesLoans5(ALLLData062008,ChargeOffData062008,LoanData062008,IDRSSD);
  
  #September 30th, 2008
  #umDep092008 <- subset(bankData8,Reporting.Period.End.Date=="9/30/2008")
  ALLLData092008 <- read.csv("FFIEC CDR Call Schedule RIBII 09302008.csv",header=TRUE);
  ChargeOffData092008 <- read.csv("FFIEC CDR Call Schedule RIBI 09302008.csv",header=TRUE);
  LoanData092008      <- read.csv("FFIEC CDR Call Schedule RCCI 09302008.csv",header=TRUE);
  
  #Indust_Loans_CH_31   <- LoanCharge5a1(sumDep092008,ChargeOffData092008,LoanData092008);
  Indust_Loans_CH_31   <- BankData_LossesLoans5(ALLLData092008,ChargeOffData092008,LoanData092008,IDRSSD);
  
  #December 31st, 2008
  #sumDep122008 <- subset(bankData8,Reporting.Period.End.Date=="12/31/2008")
  ALLLData122008 <- read.csv("FFIEC CDR Call Schedule RIBII 12312008.csv",header=TRUE);
  ChargeOffData122008 <- read.csv("FFIEC CDR Call Schedule RIBI 12312008.csv",header=TRUE);
  LoanData122008      <- read.csv("FFIEC CDR Call Schedule RCCI 12312008.csv",header=TRUE);
  
  #Indust_Loans_CH_32   <- LoanCharge5a1(sumDep122008,ChargeOffData122008,LoanData122008);
  Indust_Loans_CH_32   <- BankData_LossesLoans5(ALLLData122008,ChargeOffData122008,LoanData122008,IDRSSD);
  
  #2009
  #bankData9 <- read.csv("bank_level_data_9a.csv",header=TRUE);
  
  #March 31st, 2009
  #sumDep2 <- subset(bankData2,Reporting.Period.End.Date=="3/31/2002")
  #sumDep032009 <- subset(bankData9,Reporting.Period.End.Date=="3/31/2009")
  ALLLData032009 <- read.csv("FFIEC CDR Call Schedule RIBII 03312009.csv",header=TRUE);
  ChargeOffData032009 <- read.csv("FFIEC CDR Call Schedule RIBI 03312009.csv",header=TRUE);
  LoanData032009      <- read.csv("FFIEC CDR Call Schedule RCCI 03312009.csv",header=TRUE);
  
  #Indust_Loans_CH_33   <- LoanCharge5a1(sumDep032009,ChargeOffData032009,LoanData032009);
  Indust_Loans_CH_33   <- BankData_LossesLoans5(ALLLData032009,ChargeOffData032009,LoanData032009,IDRSSD);
  
  #June 30th, 2009
  #sumDep062009        <- subset(bankData9,Reporting.Period.End.Date=="6/30/2009")
  ALLLData062009 <- read.csv("FFIEC CDR Call Schedule RIBII 06302009.csv",header=TRUE);
  ChargeOffData062009 <- read.csv("FFIEC CDR Call Schedule RIBI 06302009.csv",header=TRUE);
  LoanData062009      <- read.csv("FFIEC CDR Call Schedule RCCI 06302009.csv",header=TRUE);
  
  #Indust_Loans_CH_34   <- LoanCharge5a1(sumDep062009,ChargeOffData062009,LoanData062009);
  Indust_Loans_CH_34   <- BankData_LossesLoans5(ALLLData062009,ChargeOffData062009,LoanData062009,IDRSSD);
  
  #September 30th, 2009
  #sumDep092009 <- subset(bankData9,Reporting.Period.End.Date=="9/30/2009")
  ALLLData092009 <- read.csv("FFIEC CDR Call Schedule RIBII 09302009.csv",header=TRUE);
  ChargeOffData092009 <- read.csv("FFIEC CDR Call Schedule RIBI 09302009.csv",header=TRUE);
  LoanData092009      <- read.csv("FFIEC CDR Call Schedule RCCI 09302009.csv",header=TRUE);
  
  #Indust_Loans_CH_35   <- LoanCharge5a1(sumDep092009,ChargeOffData092009,LoanData092009);
  Indust_Loans_CH_35   <- BankData_LossesLoans5(ALLLData092009,ChargeOffData092009,LoanData092009,IDRSSD);
  
  #December 31st, 2009
  #sumDep122009 <- subset(bankData9,Reporting.Period.End.Date=="12/31/2009")
  ALLLData122009 <- read.csv("FFIEC CDR Call Schedule RIBII 12312009.csv",header=TRUE);
  ChargeOffData122009 <- read.csv("FFIEC CDR Call Schedule RIBI 12312009.csv",header=TRUE);
  LoanData122009      <- read.csv("FFIEC CDR Call Schedule RCCI 12312009.csv",header=TRUE);
  
  #Indust_Loans_CH_36   <- LoanCharge5a1(sumDep122009,ChargeOffData122009,LoanData122009);
  Indust_Loans_CH_36   <- BankData_LossesLoans5(ALLLData122009,ChargeOffData122009,LoanData122009,IDRSSD);
  
  #2010
  #bankData10 <- read.csv("bank_level_data_10a.csv",header=TRUE);
  
  #March 31st, 2010
  #sumDep2 <- subset(bankData2,Reporting.Period.End.Date=="3/31/2002")
  #sumDep032010         <- subset(bankData10,Reporting.Period.End.Date=="3/31/2010")
  ALLLData032010 <- read.csv("FFIEC CDR Call Schedule RIBII 03312010.csv",header=TRUE);
  ChargeOffData032010 <- read.csv("FFIEC CDR Call Schedule RIBI 03312010.csv",header=TRUE);
  LoanData032010      <- read.csv("FFIEC CDR Call Schedule RCCI 03312010.csv",header=TRUE);
  
  #Indust_Loans_CH_37   <- LoanCharge6a1(sumDep032010,ChargeOffData032010,LoanData032010);
  Indust_Loans_CH_37   <- BankData_LossesLoans6(ALLLData032010,ChargeOffData032010,LoanData032010,IDRSSD);
  
  #June 30th, 2010
  #sumDep062010        <- subset(bankData10,Reporting.Period.End.Date=="6/30/2010")
  ALLLData062010 <- read.csv("FFIEC CDR Call Schedule RIBII 06302010.csv",header=TRUE);
  ChargeOffData062010 <- read.csv("FFIEC CDR Call Schedule RIBI 06302010.csv",header=TRUE);
  LoanData062010      <- read.csv("FFIEC CDR Call Schedule RCCI 06302010.csv",header=TRUE);
  
  #Indust_Loans_CH_38   <- LoanCharge6a1(sumDep062010,ChargeOffData062010,LoanData062010);
  Indust_Loans_CH_38   <- BankData_LossesLoans6(ALLLData062010,ChargeOffData062010,LoanData062010, IDRSSD);
  
  #September 30th, 2010
  #sumDep092010 <- subset(bankData10,Reporting.Period.End.Date=="9/30/2010")
  ALLLData092010 <- read.csv("FFIEC CDR Call Schedule RIBII 09302010.csv",header=TRUE);
  ChargeOffData092010 <- read.csv("FFIEC CDR Call Schedule RIBI 09302010.csv",header=TRUE);
  LoanData092010      <- read.csv("FFIEC CDR Call Schedule RCCI 09302010.csv",header=TRUE);
  
  #Indust_Loans_CH_39   <- LoanCharge6a1(sumDep092010,ChargeOffData092010,LoanData092010);
  Indust_Loans_CH_39   <- BankData_LossesLoans6(ALLLData092010,ChargeOffData092010,LoanData092010,IDRSSD);
  
  #December 31st, 2010
  #sumDep122010 <- subset(bankData10,Reporting.Period.End.Date=="12/31/2010")
  ALLLData122010 <- read.csv("FFIEC CDR Call Schedule RIBII 12312010.csv",header=TRUE);
  ChargeOffData122010 <- read.csv("FFIEC CDR Call Schedule RIBI 12312010.csv",header=TRUE);
  LoanData122010      <- read.csv("FFIEC CDR Call Schedule RCCI 12312010.csv",header=TRUE);
  
  #Indust_Loans_CH_40   <- LoanCharge6a1(sumDep122010,ChargeOffData122010,LoanData122010);
  Indust_Loans_CH_40   <- BankData_LossesLoans6(ALLLData122010,ChargeOffData122010,LoanData122010, IDRSSD);
  
  #2011
  #bankData11 <- read.csv("bank_level_data_11a1.csv",header=TRUE);
  
  #March 31st, 2011
  #sumDep2 <- subset(bankData2,Reporting.Period.End.Date=="3/31/2002")
  #sumDep032011         <- subset(bankData11,Reporting.Period.End.Date=="3/31/2011")
  ALLLData032011 <- read.csv("FFIEC CDR Call Schedule RIBII 03312011.csv",header=TRUE);
  ChargeOffData032011 <- read.csv("FFIEC CDR Call Schedule RIBI 03312011.csv",header=TRUE);
  LoanData032011      <- read.csv("FFIEC CDR Call Schedule RCCI 03312011.csv",header=TRUE);
  
  #Indust_Loans_CH_41   <- LoanCharge7a(sumDep032011,ChargeOffData032011,LoanData032011);
  Indust_Loans_CH_41   <- BankData_LossesLoans7(ALLLData032011,ChargeOffData032011,LoanData032011, IDRSSD);
  
  #June 30th, 2011
  #sumDep062011        <- subset(bankData11,Reporting.Period.End.Date=="6/30/2011")
  ALLLData062011 <- read.csv("FFIEC CDR Call Schedule RIBII 06302011.csv",header=TRUE);
  ChargeOffData062011 <- read.csv("FFIEC CDR Call Schedule RIBI 06302011.csv",header=TRUE);
  LoanData062011      <- read.csv("FFIEC CDR Call Schedule RCCI 06302011.csv",header=TRUE);
  
  #Indust_Loans_CH_42   <- LoanCharge7a(sumDep062011,ChargeOffData062011,LoanData062011);
  Indust_Loans_CH_42   <- BankData_LossesLoans7(ALLLData062011,ChargeOffData062011,LoanData062011,IDRSSD);
  
  #September 30th, 2011
  #sumDep092011 <- subset(bankData11,Reporting.Period.End.Date=="9/30/2011")
  ALLLData092011 <- read.csv("FFIEC CDR Call Schedule RIBII 09302011.csv",header=TRUE);
  ChargeOffData092011 <- read.csv("FFIEC CDR Call Schedule RIBI 09302011.csv",header=TRUE);
  LoanData092011      <- read.csv("FFIEC CDR Call Schedule RCCI 09302011.csv",header=TRUE);
  
  #Indust_Loans_CH_43   <- LoanCharge7a(sumDep092011,ChargeOffData092011,LoanData092011);
  Indust_Loans_CH_43   <- BankData_LossesLoans7(ALLLData092011,ChargeOffData092011,LoanData092011,IDRSSD);
  
  #December 31st, 2011
  #sumDep122011 <- subset(bankData11,Reporting.Period.End.Date=="12/31/2011")
  ALLLData122011 <- read.csv("FFIEC CDR Call Schedule RIBII 12312011.csv",header=TRUE);
  ChargeOffData122011 <- read.csv("FFIEC CDR Call Schedule RIBI 12312011.csv",header=TRUE);
  LoanData122011      <- read.csv("FFIEC CDR Call Schedule RCCI 12312011.csv",header=TRUE);
  
  #Indust_Loans_CH_44   <- LoanCharge7a(sumDep122011,ChargeOffData122011,LoanData122011);
  Indust_Loans_CH_44   <- BankData_LossesLoans7(ALLLData122011,ChargeOffData122011,LoanData122011,IDRSSD);
  
  #2012
  #bankData12 <- read.csv("bank_level_data_12a1.csv",header=TRUE);
  
  #March 31st, 2012
  #sumDep2 <- subset(bankData2,Reporting.Period.End.Date=="3/31/2002")
  #sumDep032012         <- subset(bankData12,Reporting.Period.End.Date=="3/31/2012")
  ALLLData032012 <- read.csv("FFIEC CDR Call Schedule RIBII 03312012.csv",header=TRUE);
  ChargeOffData032012 <- read.csv("FFIEC CDR Call Schedule RIBI 03312012.csv",header=TRUE);
  LoanData032012      <- read.csv("FFIEC CDR Call Schedule RCCI 03312012.csv",header=TRUE);
  
  #Indust_Loans_CH_45   <- LoanCharge7a(sumDep032012,ChargeOffData032012,LoanData032012);
  Indust_Loans_CH_45   <- BankData_LossesLoans7(ALLLData032012,ChargeOffData032012,LoanData032012, IDRSSD);
  
  #June 30th, 2012
  #sumDep062012        <- subset(bankData12,Reporting.Period.End.Date=="6/30/2012")
  ALLLData062012 <- read.csv("FFIEC CDR Call Schedule RIBII 06302012.csv",header=TRUE);
  ChargeOffData062012 <- read.csv("FFIEC CDR Call Schedule RIBI 06302012.csv",header=TRUE);
  LoanData062012      <- read.csv("FFIEC CDR Call Schedule RCCI 06302012.csv",header=TRUE);
  
  #Indust_Loans_CH_46   <- LoanCharge7a(sumDep062012,ChargeOffData062012,LoanData062012);
  Indust_Loans_CH_46   <- BankData_LossesLoans7(ALLLData062012,ChargeOffData062012,LoanData062012, IDRSSD);
  
  #September 30th, 2012
  #sumDep092012        <- subset(bankData12,Reporting.Period.End.Date=="9/30/2012")
  ALLLData092012 <- read.csv("FFIEC CDR Call Schedule RIBII 09302012.csv",header=TRUE);
  ChargeOffData092012 <- read.csv("FFIEC CDR Call Schedule RIBI 09302012.csv",header=TRUE);
  LoanData092012      <- read.csv("FFIEC CDR Call Schedule RCCI 09302012.csv",header=TRUE);
  
  #Indust_Loans_CH_47   <- LoanCharge7a(sumDep092012,ChargeOffData092012,LoanData092012);
  Indust_Loans_CH_47   <- BankData_LossesLoans7(ALLLData092012,ChargeOffData092012,LoanData092012, IDRSSD);
  
  #December 31st, 2012
  #sumDep122012 <- subset(bankData12,Reporting.Period.End.Date=="12/31/2012")
  ALLLData122012 <- read.csv("FFIEC CDR Call Schedule RIBII 12312012.csv",header=TRUE);
  ChargeOffData122012 <- read.csv("FFIEC CDR Call Schedule RIBI 12312012.csv",header=TRUE);
  LoanData122012      <- read.csv("FFIEC CDR Call Schedule RCCI 12312012.csv",header=TRUE);
  
  #Indust_Loans_CH_48   <- LoanCharge7a(sumDep122012,ChargeOffData122012,LoanData122012);
  Indust_Loans_CH_48   <- BankData_LossesLoans7(ALLLData122012,ChargeOffData122012,LoanData122012, IDRSSD);
  
  #2013
  #bankData13 <- read.csv("bank_level_data_13a1.csv",header=TRUE);
  
  #March 31st, 2013
  #sumDep2 <- subset(bankData2,Reporting.Period.End.Date=="3/31/2012")
  #sumDep032013         <- subset(bankData13,Reporting.Period.End.Date=="3/31/2013")
  ALLLData032013 <- read.csv("FFIEC CDR Call Schedule RIBII 03312013.csv",header=TRUE);
  ChargeOffData032013 <- read.csv("FFIEC CDR Call Schedule RIBI 03312013.csv",header=TRUE);
  LoanData032013      <- read.csv("FFIEC CDR Call Schedule RCCI 03312013.csv",header=TRUE);
  
  #Indust_Loans_CH_49   <- LoanCharge7a(sumDep032013,ChargeOffData032013,LoanData032013);
  Indust_Loans_CH_49   <- BankData_LossesLoans7(ALLLData032013,ChargeOffData032013,LoanData032013, IDRSSD);
  
  #June 30th, 2013
  #sumDep062013        <- subset(bankData13,Reporting.Period.End.Date=="6/30/2013")
  ALLLData062013 <- read.csv("FFIEC CDR Call Schedule RIBII 06302013.csv",header=TRUE);
  ChargeOffData062013 <- read.csv("FFIEC CDR Call Schedule RIBI 06302013.csv",header=TRUE);
  LoanData062013      <- read.csv("FFIEC CDR Call Schedule RCCI 06302013.csv",header=TRUE);
  
  #Indust_Loans_CH_50   <- LoanCharge7a(sumDep062013,ChargeOffData062013,LoanData062013);
  Indust_Loans_CH_50   <- BankData_LossesLoans7(ALLLData062013,ChargeOffData062013,LoanData062013, IDRSSD);
  
  #September 30th, 2013
  #sumDep092013        <- subset(bankData13,Reporting.Period.End.Date=="9/30/2013")
  ALLLData092013 <- read.csv("FFIEC CDR Call Schedule RIBII 09302013.csv",header=TRUE);
  ChargeOffData092013 <- read.csv("FFIEC CDR Call Schedule RIBI 09302013.csv",header=TRUE);
  LoanData092013      <- read.csv("FFIEC CDR Call Schedule RCCI 09302013.csv",header=TRUE);
  
  #Indust_Loans_CH_51   <- LoanCharge7a(sumDep092013,ChargeOffData092013,LoanData092013);
  Indust_Loans_CH_51   <- BankData_LossesLoans7(ALLLData092013,ChargeOffData092013,LoanData092013, IDRSSD);
  
  #December 31st, 2013
  #sumDep122013 <- subset(bankData13,Reporting.Period.End.Date=="12/31/2013")
  ALLLData122013 <- read.csv("FFIEC CDR Call Schedule RIBII 12312013.csv",header=TRUE);
  ChargeOffData122013 <- read.csv("FFIEC CDR Call Schedule RIBI 12312013.csv",header=TRUE);
  LoanData122013      <- read.csv("FFIEC CDR Call Schedule RCCI 12312013.csv",header=TRUE);
  
  #Indust_Loans_CH_52   <- LoanCharge7a(sumDep122013,ChargeOffData122013,LoanData122013);
  Indust_Loans_CH_52   <- BankData_LossesLoans7(ALLLData122013,ChargeOffData122013,LoanData122013, IDRSSD);
  
  #2014
  #bankData14 <- read.csv("bank_level_data_14a1.csv",header=TRUE);
  
  #March 31st, 2014
  #sumDep2 <- subset(bankData2,Reporting.Period.End.Date=="3/31/2012")
  #sumDep032014        <- subset(bankData14,Reporting.Period.End.Date=="3/31/2014")
  ALLLData032014 <- read.csv("FFIEC CDR Call Schedule RIBII 03312014.csv",header=TRUE);
  ChargeOffData032014 <- read.csv("FFIEC CDR Call Schedule RIBI 03312014.csv",header=TRUE);
  LoanData032014      <- read.csv("FFIEC CDR Call Schedule RCCI 03312014.csv",header=TRUE);
  
  #Indust_Loans_CH_53  <- LoanCharge7a(sumDep032014,ChargeOffData032014,LoanData032014);
  Indust_Loans_CH_53  <- BankData_LossesLoans7(ALLLData032014,ChargeOffData032014,LoanData032014, IDRSSD);
  
  #June 30th, 2014
  #sumDep062014        <- subset(bankData14,Reporting.Period.End.Date=="6/30/2014")
  ALLLData062014 <- read.csv("FFIEC CDR Call Schedule RIBII 06302014.csv",header=TRUE);
  ChargeOffData062014 <- read.csv("FFIEC CDR Call Schedule RIBI 06302014.csv",header=TRUE);
  LoanData062014      <- read.csv("FFIEC CDR Call Schedule RCCI 06302014.csv",header=TRUE);
  
  #Indust_Loans_CH_54   <- LoanCharge7a(sumDep062014,ChargeOffData062014,LoanData062014);
  Indust_Loans_CH_54   <- BankData_LossesLoans7(ALLLData062014,ChargeOffData062014,LoanData062014, IDRSSD);
  
  #September 30th, 2014
  #sumDep092014        <- subset(bankData14,Reporting.Period.End.Date=="9/30/2014")
  ALLLData092014 <- read.csv("FFIEC CDR Call Schedule RIBII 09302014.csv",header=TRUE);
  ChargeOffData092014 <- read.csv("FFIEC CDR Call Schedule RIBI 09302014.csv",header=TRUE);
  LoanData092014      <- read.csv("FFIEC CDR Call Schedule RCCI 09302014.csv",header=TRUE);
  
  #Indust_Loans_CH_55   <- LoanCharge7a(sumDep092014,ChargeOffData092014,LoanData092014);
  Indust_Loans_CH_55   <- BankData_LossesLoans7(ALLLData092014,ChargeOffData092014,LoanData092014, IDRSSD);
  
  #December 31st, 2014
  #sumDep122014 <- subset(bankData14,Reporting.Period.End.Date=="12/31/2014")
  ALLLData122014 <- read.csv("FFIEC CDR Call Schedule RIBII 12312014.csv",header=TRUE);
  ChargeOffData122014 <- read.csv("FFIEC CDR Call Schedule RIBI 12312014.csv",header=TRUE);
  LoanData122014      <- read.csv("FFIEC CDR Call Schedule RCCI 12312014.csv",header=TRUE);
  
  #Indust_Loans_CH_56   <- LoanCharge7a(sumDep122014,ChargeOffData122014,LoanData122014);
  Indust_Loans_CH_56   <- BankData_LossesLoans7(ALLLData122014,ChargeOffData122014,LoanData122014, IDRSSD);
  
  
  #2015
  #bankData15 <- read.csv("bank_level_data_15a1.csv",header=TRUE);
  
  #March 31st, 2015
  #sumDep2 <- subset(bankData2,Reporting.Period.End.Date=="3/31/2012")
  #sumDep032015         <- subset(bankData15,Reporting.Period.End.Date=="3/31/2015")
  ALLLData032015  <- read.csv("FFIEC CDR Call Schedule RIBII 03312015.csv",header=TRUE);
  ChargeOffData032015  <- read.csv("FFIEC CDR Call Schedule RIBI 03312015.csv",header=TRUE);
  LoanData032015       <- read.csv("FFIEC CDR Call Schedule RCCI 03312015.csv",header=TRUE);
  
  #Indust_Loans_CH_57   <- LoanCharge7a(sumDep032015,ChargeOffData032015,LoanData032015);
  Indust_Loans_CH_57   <- BankData_LossesLoans7(ALLLData032015,ChargeOffData032015,LoanData032015,IDRSSD);
  
  #June 30th, 2015
  #sumDep062015        <- subset(bankData15,Reporting.Period.End.Date=="6/30/2015")
  ALLLData062015 <- read.csv("FFIEC CDR Call Schedule RIBII 06302015.csv",header=TRUE);
  ChargeOffData062015 <- read.csv("FFIEC CDR Call Schedule RIBI 06302015.csv",header=TRUE);
  LoanData062015      <- read.csv("FFIEC CDR Call Schedule RCCI 06302015.csv",header=TRUE);
  
  #Indust_Loans_CH_58   <- LoanCharge7a(sumDep062015,ChargeOffData062015,LoanData062015);
  Indust_Loans_CH_58   <- BankData_LossesLoans7(ALLLData062015,ChargeOffData062015,LoanData062015, IDRSSD);
  
  #September 30th, 2015
  #sumDep092015        <- subset(bankData15,Reporting.Period.End.Date=="9/30/2015")
  ALLLData092015 <- read.csv("FFIEC CDR Call Schedule RIBII 09302015.csv",header=TRUE);
  ChargeOffData092015 <- read.csv("FFIEC CDR Call Schedule RIBI 09302015.csv",header=TRUE);
  LoanData092015      <- read.csv("FFIEC CDR Call Schedule RCCI 09302015.csv",header=TRUE);
  
  #Indust_Loans_CH_59   <- LoanCharge7a(sumDep092015,ChargeOffData092015,LoanData092015);
  Indust_Loans_CH_59   <- BankData_LossesLoans7(ALLLData092015,ChargeOffData092015, LoanData092015, IDRSSD);
  
  #December 31st, 2015
  #sumDep122015 <- subset(bankData15,Reporting.Period.End.Date=="12/31/2015")
  ALLLData122015 <- read.csv("FFIEC CDR Call Schedule RIBII 12312015.csv",header=TRUE);
  ChargeOffData122015 <- read.csv("FFIEC CDR Call Schedule RIBI 12312015.csv",header=TRUE);
  LoanData122015      <- read.csv("FFIEC CDR Call Schedule RCCI 12312015.csv",header=TRUE);
  
  #Indust_Loans_CH_60   <- LoanCharge7a(sumDep122015,ChargeOffData122015,LoanData122015);
  Indust_Loans_CH_60   <- BankData_LossesLoans7(ALLLData122015,ChargeOffData122015,LoanData122015, IDRSSD);
  
  #2016
 # bankData16 <- read.csv("bank_level_data_16a.csv",header=TRUE);
  
  #March 31st, 2016
  #sumDep2 <- subset(bankData2,Reporting.Period.End.Date=="3/31/2016")
  #sumDep032016         <- subset(bankData16,Reporting.Period.End.Date=="3/31/2016")
  ALLLData032016  <- read.csv("FFIEC CDR Call Schedule RIBII 03312016.csv",header=TRUE);
  ChargeOffData032016  <- read.csv("FFIEC CDR Call Schedule RIBI 03312016.csv",header=TRUE);
  LoanData032016       <- read.csv("FFIEC CDR Call Schedule RCCI 03312016.csv",header=TRUE);
  
  #Indust_Loans_CH_61  <- LoanCharge7a(sumDep032016,ChargeOffData032016,LoanData032016);
  
  Indust_Loans_CH_61  <- BankData_LossesLoans7(ALLLData032016,ChargeOffData032016,LoanData032016, IDRSSD);
  
  #June 30th, 2016
  #sumDep062016        <- subset(bankData16,Reporting.Period.End.Date=="6/30/2016")
  ALLLData062016 <- read.csv("FFIEC CDR Call Schedule RIBII 06302016.csv",header=TRUE);
  ChargeOffData062016 <- read.csv("FFIEC CDR Call Schedule RIBI 06302016.csv",header=TRUE);
  LoanData062016     <- read.csv("FFIEC CDR Call Schedule RCCI 06302016.csv",header=TRUE);
  
  #Indust_Loans_CH_62   <- LoanCharge7a(sumDep062016,ChargeOffData062016,LoanData062016);
  
  Indust_Loans_CH_62   <- BankData_LossesLoans7(ALLLData062016,ChargeOffData062016,LoanData062016,IDRSSD)
  
  #September 30th, 2016
  #sumDep092015        <- subset(bankData15,Reporting.Period.End.Date=="9/30/2016")
  ALLLData092016 <- read.csv("FFIEC CDR Call Schedule RIBII 09302016.csv",header=TRUE);
  ChargeOffData092016 <- read.csv("FFIEC CDR Call Schedule RIBI 09302016.csv",header=TRUE);
  LoanData092016      <- read.csv("FFIEC CDR Call Schedule RCCI 09302016.csv",header=TRUE);
  
  #Indust_Loans_CH_59   <- LoanCharge7a(sumDep092015,ChargeOffData092015,LoanData092015);
  Indust_Loans_CH_63   <- BankData_LossesLoans7(ALLLData092016,ChargeOffData092016, LoanData092016, IDRSSD);
  
  #December 31st, 2015
  #sumDep122015 <- subset(bankData15,Reporting.Period.End.Date=="12/31/2016")
  ALLLData122016 <- read.csv("FFIEC CDR Call Schedule RIBII 12312016.csv",header=TRUE);
  ChargeOffData122016 <- read.csv("FFIEC CDR Call Schedule RIBI 12312016.csv",header=TRUE);
  LoanData122016      <- read.csv("FFIEC CDR Call Schedule RCCI 12312016.csv",header=TRUE);
  
  #Indust_Loans_CH_60   <- LoanCharge7a(sumDep122015,ChargeOffData122015,LoanData122015);
  Indust_Loans_CH_64   <- BankData_LossesLoans7(ALLLData122016,ChargeOffData122016,LoanData122016, IDRSSD);
  
  #2017
  
  #NEW - UPDATE 2/5/19
  #March 31st, 2017
  #sumDep2 <- subset(bankData2,Reporting.Period.End.Date=="3/31/2012")
  #sumDep032015         <- subset(bankData15,Reporting.Period.End.Date=="3/31/2017")
  ALLLData032017  <- read.csv("FFIEC CDR Call Schedule RIBII 03312017.csv",header=TRUE);
  ChargeOffData032017  <- read.csv("FFIEC CDR Call Schedule RIBI 03312017.csv",header=TRUE);
  LoanData032017       <- read.csv("FFIEC CDR Call Schedule RCCI 03312017.csv",header=TRUE);
  
  #Indust_Loans_CH_57   <- LoanCharge7a(sumDep032015,ChargeOffData032015,LoanData032015);
  Indust_Loans_CH_65   <- BankData_LossesLoans8(ALLLData032017,ChargeOffData032017,LoanData032017,IDRSSD);
  
  #June 30th, 2017
  #sumDep062015        <- subset(bankData15,Reporting.Period.End.Date=="6/30/2017")
  ALLLData062017 <- read.csv("FFIEC CDR Call Schedule RIBII 06302017.csv",header=TRUE);
  ChargeOffData062017 <- read.csv("FFIEC CDR Call Schedule RIBI 06302017.csv",header=TRUE);
  LoanData062017      <- read.csv("FFIEC CDR Call Schedule RCCI 06302017.csv",header=TRUE);
  
  #Indust_Loans_CH_58   <- LoanCharge7a(sumDep062015,ChargeOffData062015,LoanData062015);
  Indust_Loans_CH_66   <- BankData_LossesLoans8(ALLLData062017,ChargeOffData062017,LoanData062017, IDRSSD);
  
  #September 30th, 2017
  #sumDep092015        <- subset(bankData15,Reporting.Period.End.Date=="9/30/2015")
  ALLLData092017 <- read.csv("FFIEC CDR Call Schedule RIBII 09302017.csv",header=TRUE);
  ChargeOffData092017 <- read.csv("FFIEC CDR Call Schedule RIBI 09302017.csv",header=TRUE);
  LoanData092017      <- read.csv("FFIEC CDR Call Schedule RCCI 09302017.csv",header=TRUE);
  
  #Indust_Loans_CH_59   <- LoanCharge7a(sumDep092015,ChargeOffData092015,LoanData092015);
  Indust_Loans_CH_67   <- BankData_LossesLoans8(ALLLData092017,ChargeOffData092017, LoanData092017, IDRSSD);
  
  #December 31st, 2017
  #sumDep122015 <- subset(bankData15,Reporting.Period.End.Date=="12/31/2015")
  ALLLData122017 <- read.csv("FFIEC CDR Call Schedule RIBII 12312017.csv",header=TRUE);
  ChargeOffData122017 <- read.csv("FFIEC CDR Call Schedule RIBI 12312017.csv",header=TRUE);
  LoanData122017      <- read.csv("FFIEC CDR Call Schedule RCCI 12312017.csv",header=TRUE);
  
  #Indust_Loans_CH_60   <- LoanCharge7a(sumDep122015,ChargeOffData122015,LoanData122015);
  Indust_Loans_CH_68   <- BankData_LossesLoans8(ALLLData122017,ChargeOffData122017,LoanData122017, IDRSSD);
  
  #2018
  # bankData16 <- read.csv("bank_level_data_16a.csv",header=TRUE);
  
  #March 31st, 2018
  #sumDep2 <- subset(bankData2,Reporting.Period.End.Date=="3/31/2016")
  #sumDep032016         <- subset(bankData16,Reporting.Period.End.Date=="3/31/2016")
  ALLLData032018  <- read.csv("FFIEC CDR Call Schedule RIBII 03312018.csv",header=TRUE);
  ChargeOffData032018  <- read.csv("FFIEC CDR Call Schedule RIBI 03312018.csv",header=TRUE);
  LoanData032018       <- read.csv("FFIEC CDR Call Schedule RCCI 03312018.csv",header=TRUE);
  
  #Indust_Loans_CH_61  <- LoanCharge7a(sumDep032016,ChargeOffData032016,LoanData032016);
  
  Indust_Loans_CH_69  <- BankData_LossesLoans8(ALLLData032018,ChargeOffData032018,LoanData032018, IDRSSD);
  
  #June 30th, 2018
  #sumDep062016        <- subset(bankData16,Reporting.Period.End.Date=="6/30/2016")
  ALLLData062018 <- read.csv("FFIEC CDR Call Schedule RIBII 06302018.csv",header=TRUE);
  ChargeOffData062018 <- read.csv("FFIEC CDR Call Schedule RIBI 06302018.csv",header=TRUE);
  LoanData062018     <- read.csv("FFIEC CDR Call Schedule RCCI 06302018.csv",header=TRUE);
  
  #Indust_Loans_CH_62   <- LoanCharge7a(sumDep062016,ChargeOffData062016,LoanData062016);
  
  Indust_Loans_CH_70   <- BankData_LossesLoans8(ALLLData062018,ChargeOffData062018,LoanData062018,IDRSSD)
  
  #September 30th, 2018
  #sumDep092015        <- subset(bankData15,Reporting.Period.End.Date=="9/30/2015")
  ALLLData092018 <- read.csv("FFIEC CDR Call Schedule RIBII 09302018.csv",header=TRUE);
  ChargeOffData092018 <- read.csv("FFIEC CDR Call Schedule RIBI 09302018.csv",header=TRUE);
  LoanData092018      <- read.csv("FFIEC CDR Call Schedule RCCI 09302018.csv",header=TRUE);
  
  #Indust_Loans_CH_59   <- LoanCharge7a(sumDep092015,ChargeOffData092015,LoanData092015);
  Indust_Loans_CH_71   <- BankData_LossesLoans8(ALLLData092018,ChargeOffData092018, LoanData092018, IDRSSD);
  
  #Now, stitch the data into a time-series
  
  CompareChargeOffRates <- data.frame(rbind(Indust_Loans_CH_1,Indust_Loans_CH_2,Indust_Loans_CH_3,Indust_Loans_CH_4,(Indust_Loans_CH_5),(Indust_Loans_CH_6),(Indust_Loans_CH_7),
                                 (Indust_Loans_CH_8),(Indust_Loans_CH_9),(Indust_Loans_CH_10),(Indust_Loans_CH_11),
                                 (Indust_Loans_CH_12),(Indust_Loans_CH_13),(Indust_Loans_CH_14),(Indust_Loans_CH_15),
                                 (Indust_Loans_CH_16),(Indust_Loans_CH_17),(Indust_Loans_CH_18),(Indust_Loans_CH_19),
                                 (Indust_Loans_CH_20),(Indust_Loans_CH_21),(Indust_Loans_CH_22),(Indust_Loans_CH_23),
                                 (Indust_Loans_CH_24),(Indust_Loans_CH_25),(Indust_Loans_CH_26),(Indust_Loans_CH_27),
                                 (Indust_Loans_CH_28),(Indust_Loans_CH_29),(Indust_Loans_CH_30),(Indust_Loans_CH_31),
                                 (Indust_Loans_CH_32),(Indust_Loans_CH_33),(Indust_Loans_CH_34),(Indust_Loans_CH_35),
                                 (Indust_Loans_CH_36),(Indust_Loans_CH_37),(Indust_Loans_CH_38),(Indust_Loans_CH_39),
                                 (Indust_Loans_CH_40),(Indust_Loans_CH_41),(Indust_Loans_CH_42),(Indust_Loans_CH_43),
                                 (Indust_Loans_CH_44),(Indust_Loans_CH_45),(Indust_Loans_CH_46),(Indust_Loans_CH_47),
                                 (Indust_Loans_CH_48),(Indust_Loans_CH_49),(Indust_Loans_CH_50),(Indust_Loans_CH_51),
                                 (Indust_Loans_CH_52),(Indust_Loans_CH_53),(Indust_Loans_CH_54),(Indust_Loans_CH_55),
                                 (Indust_Loans_CH_56),(Indust_Loans_CH_57),(Indust_Loans_CH_58),(Indust_Loans_CH_59),
                                 (Indust_Loans_CH_60),(Indust_Loans_CH_61),(Indust_Loans_CH_62),
                                 (Indust_Loans_CH_63),(Indust_Loans_CH_64),(Indust_Loans_CH_65),
                                 (Indust_Loans_CH_66),(Indust_Loans_CH_67),(Indust_Loans_CH_68),
                                 (Indust_Loans_CH_69),(Indust_Loans_CH_70),(Indust_Loans_CH_71)));

#CompareChargeOffRates <- rbind(CompareChargeOffRates,(Indust_Loans_CH_5),(Indust_Loans_CH_6),(Indust_Loans_CH_7),
#                               (Indust_Loans_CH_8),(Indust_Loans_CH_9),(Indust_Loans_CH_10),(Indust_Loans_CH_11));
#,(Indust_Loans_CH_12),(Indust_Loans_CH_13),(Indust_Loans_CH_14),(Indust_Loans_CH_15),
#(Indust_Loans_CH_16),(Indust_Loans_CH_17),(Indust_Loans_CH_18),(Indust_Loans_CH_19),
#(Indust_Loans_CH_20),(Indust_Loans_CH_21),(Indust_Loans_CH_22),(Indust_Loans_CH_23),
#(Indust_Loans_CH_24),(Indust_Loans_CH_25),(Indust_Loans_CH_26),(Indust_Loans_CH_27),
#(Indust_Loans_CH_28),(Indust_Loans_CH_29),(Indust_Loans_CH_30),(Indust_Loans_CH_31),
#(Indust_Loans_CH_32),(Indust_Loans_CH_33),(Indust_Loans_CH_34),(Indust_Loans_CH_35),
#(Indust_Loans_CH_36),(Indust_Loans_CH_37),(Indust_Loans_CH_38),(Indust_Loans_CH_39),
#(Indust_Loans_CH_40),(Indust_Loans_CH_41),(Indust_Loans_CH_42),(Indust_Loans_CH_43),
#(Indust_Loans_CH_44),(Indust_Loans_CH_45),(Indust_Loans_CH_46),(Indust_Loans_CH_47),
#(Indust_Loans_CH_48),(Indust_Loans_CH_49),(Indust_Loans_CH_50),(Indust_Loans_CH_51),
#(Indust_Loans_CH_52),(Indust_Loans_CH_53),(Indust_Loans_CH_54),(Indust_Loans_CH_55),
#(Indust_Loans_CH_56),(Indust_Loans_CH_57),(Indust_Loans_CH_58),(Indust_Loans_CH_59),
#(Indust_Loans_CH_60),(Indust_Loans_CH_61),(Indust_Loans_CH_62));
  dates_GCO <- seq(from =2001 +1/4,to= 2018+(9/12), by=1/4);
  
  CompareChargeOffRates <- cbind(CompareChargeOffRates,dates_GCO)
  CompareChargeOffRates["ALLL_Ratio"] <- CompareChargeOffRates$ALLLBal/CompareChargeOffRates$Loan_9;
  CompareChargeOffRates["Provsn_Ratio"] <- CompareChargeOffRates$ALLLProvsn/CompareChargeOffRates$Loan_9;
  CompareChargeOffRates["ALLL_NCO"] <- CompareChargeOffRates$ALLLBal/(CompareChargeOffRates$ALLLCO-CompareChargeOffRates$ALLLRCV)
  CompareChargeOffRates["ProvsnL_NCO"] <- CompareChargeOffRates$Provsn/(CompareChargeOffRates$ALLLCO-CompareChargeOffRates$ALLLRCV)
  
  return(CompareChargeOffRates)
}