
LoanCharge5a1 <- function(sumDep, ChargeOffData, LoanData) {
  
  rankedBanks <- sumDep[order(-sumDep$RCON2170),];
  
  #Take the IDRSSD from Top 50 Banks
  
  IDRSSD <- as.numeric(rankedBanks$IDRSSD[1:50]);
  #Append the array with USAA
  IDRSSD[51] <- 2502656; #USAA Unique ID RSSD
  
  #Initialize vectors to collect relevant loan data
  
  ChargeOff_1a <- matrix(NA,51,1); Loan_1a <- matrix(NA,51,1); ChargeOff_1b <- matrix(NA,51,1); Loan_1b <- matrix(NA,51,1); 
  ChargeOff_1c1 <- matrix(NA,51,1); Loan_1c1 <- matrix(NA,51,1); ChargeOff_1c2 <- matrix(NA,51,1); 
  Loan_1c2 <- matrix(NA,51,1); ChargeOff_1d <- matrix(NA,51,1); Loan_1d <- matrix(NA,51,1); ChargeOff_1e <- matrix(NA,51,1);
  Loan_1e <- matrix(NA,51,1); ChargeOff_2a <- matrix(NA,51,1); Loan_2a <- matrix(NA,51,1); ChargeOff_2b <- matrix(NA,51,1);
  Loan_2b <- matrix(NA,51,1); ChargeOff_2c <- matrix(NA,51,1); Loan_2c <- matrix(NA,51,1);
  ChargeOff_3 <- matrix(NA,51,1); Loan_3 <- matrix(NA,51,1); ChargeOff_4a <- matrix(NA,51,1); Loan_4a <- matrix(NA,51,1);
  ChargeOff_4b <- matrix(NA,51,1); Loan_4b <- matrix(NA,51,1); ChargeOff_5a <- matrix(NA,51,1); Loan_5a <- matrix(NA,51,1);
  ChargeOff_5b <- matrix(NA,51,1); Loan_5b <- matrix(NA,51,1);ChargeOff_5c <- matrix(NA,51,1); Loan_5c <- matrix(NA,51,1); 
  ChargeOff_6 <- matrix(NA,51,1); Loan_6 <- matrix(NA,51,1); 
  ChargeOff_7 <- matrix(NA,51,1); Loan_7 <- matrix(NA,51,1); ChargeOff_8a <- matrix(NA,51,1); Loan_8a <- matrix(NA,51,1);
  ChargeOff_8b <- matrix(NA,51,1); Loan_8b <- matrix(NA,51,1); ChargeOff_9 <- matrix(NA,51,1); Loan_9 <- matrix(NA,51,1);
  
  for (i in 1:51){
    #1. Loans secured by real estate 
    
    #a. Construction, land development, and other land loans in domestic offices
    ChargeOff_1a[i] <- ChargeOffData$RIADC891[ChargeOffData$IDRSSD == IDRSSD[i]] +
                        ChargeOffData$RIADC893[ChargeOffData$IDRSSD == IDRSSD[i]];
    
    #Domestic Offices (Column B)
    Loan_1a[i]      <- LoanData$RCONF158[ChargeOffData$IDRSSD == IDRSSD[i]] +
                       LoanData$RCONF159[ChargeOffData$IDRSSD == IDRSSD[i]];
    #b. Loans secured by real estate - secured by farmland in domestic offices
    ChargeOff_1b[i] <- ChargeOffData$RIAD3584[ChargeOffData$IDRSSD == IDRSSD[i]];
    Loan_1b[i]      <- LoanData$RCON1420[ChargeOffData$IDRSSD == IDRSSD[i]];
    #c. secured by 1-4 family residential properties in domestic offices
    # 1. Revolving, open-end loans secured by 1-4 family residential properties and extended under 
    # lines of credit
    ChargeOff_1c1[i] <- ChargeOffData$RIAD5411[ChargeOffData$IDRSSD == IDRSSD[i]];
    Loan_1c1[i]      <- LoanData$RCON1797[ChargeOffData$IDRSSD == IDRSSD[i]];
    
    #2. Closed-end loans secured by 1-4 family residential properties
    ChargeOff_1c2[i] <- ChargeOffData$RIADC234[ChargeOffData$IDRSSD == IDRSSD[i]] +
                        ChargeOffData$RIADC235[ChargeOffData$IDRSSD == IDRSSD[i]];
    Loan_1c2[i]      <- LoanData$RCON5367[ChargeOffData$IDRSSD == IDRSSD[i]] +
      LoanData$RCON5368[ChargeOffData$IDRSSD == IDRSSD[i]];
    #d. Secured by multifamily (5 or more) residential properties in domestic offices
    ChargeOff_1d[i] <- ChargeOffData$RIAD3588[ChargeOffData$IDRSSD == IDRSSD[i]];
    Loan_1d[i]      <- LoanData$RCON1460[ChargeOffData$IDRSSD == IDRSSD[i]];
    
    #e. Secured by nonfarm nonresidential properties in domestic offices 
    ChargeOff_1e[i] <- ChargeOffData$RIADC895[ChargeOffData$IDRSSD == IDRSSD[i]] +
                       ChargeOffData$RIADC897[ChargeOffData$IDRSSD == IDRSSD[i]];
    Loan_1e[i]      <- LoanData$RCONF160[ChargeOffData$IDRSSD == IDRSSD[i]] +
                       LoanData$RCONF161[ChargeOffData$IDRSSD == IDRSSD[i]];
    
    #f. Secured by nonfarm nonresidential properties in FOREIGN offices 
    #ChargeOff_1f[i] <- ChargeOffData$RIADB512[ChargeOffData$IDRSSD == IDRSSD[i]];
    #Loan_1f[i]      <- LoanData$RCONB531[ChargeOffData$IDRSSD == IDRSSD[i]];
    
    #2 Loans to depository institutions and acceptances of other banks 
    #a. To U.S. banks and other U.S. depository institutions
    ChargeOff_2a[i] <- ChargeOffData$RIAD4653[ChargeOffData$IDRSSD == IDRSSD[i]];
    Loan_2a[i]      <- LoanData$RCONB531[ChargeOffData$IDRSSD == IDRSSD[i]];
    
    #b. To foreign banks
    ChargeOff_2b[i] <- ChargeOffData$RIAD4654[ChargeOffData$IDRSSD == IDRSSD[i]];
    Loan_2b[i]      <- LoanData$RCONB534[ChargeOffData$IDRSSD == IDRSSD[i]];
    
    # c. To bank in foreign countries - add later maybe?
    #Loan_2c[i]      <- LoanData$RCONB535[ChargeOffData$IDRSSD == IDRSSD[i]];
    
    #3. Loans to finance agricultural production and other loans to farmers
    ChargeOff_3[i] <- ChargeOffData$RIAD4655[ChargeOffData$IDRSSD == IDRSSD[i]];
    Loan_3[i]      <- LoanData$RCON1590[ChargeOffData$IDRSSD == IDRSSD[i]];
    
    #4. Commercial and industrial loans
    #a. To U.S. addressees (domicile)
    ChargeOff_4a[i] <- ChargeOffData$RIAD4645[ChargeOffData$IDRSSD == IDRSSD[i]];
    Loan_4a[i]      <- LoanData$RCON1763[ChargeOffData$IDRSSD == IDRSSD[i]];
    
    #4. Commercial and industrial loans
    #a. To U.S. addressees (domicile)
    ChargeOff_4b[i] <- ChargeOffData$RIAD4646[ChargeOffData$IDRSSD == IDRSSD[i]];
    Loan_4b[i]      <- LoanData$RCON1764[ChargeOffData$IDRSSD == IDRSSD[i]];
    
    #5. Loans to individuals for household, family, and other personal expenditures
    #a. Credit cards
    ChargeOff_5a[i] <- ChargeOffData$RIADB514[ChargeOffData$IDRSSD == IDRSSD[i]];
    #Discrepancy - 5 is N/A in RC
    Loan_5a[i]      <- LoanData$RCONB538[ChargeOffData$IDRSSD == IDRSSD[i]];
    
    #b. Other (includes single payment, installment, all student loans, and revolving credit plans 
    #other than credit cards)
    ChargeOff_5b[i] <- ChargeOffData$RIADB516[ChargeOffData$IDRSSD == IDRSSD[i]];
    Loan_5b[i]      <- LoanData$RCONB539[ChargeOffData$IDRSSD == IDRSSD[i]] +
      LoanData$RCON2011[ChargeOffData$IDRSSD == IDRSSD[i]];
    
    #6. Loans to foreign governments and official institutions
    ChargeOff_6[i] <- ChargeOffData$RIAD4643[ChargeOffData$IDRSSD == IDRSSD[i]];
    Loan_6[i]      <- LoanData$RCON2081[ChargeOffData$IDRSSD == IDRSSD[i]];
    
    #7. All other loans
    ChargeOff_7[i] <- ChargeOffData$RIAD4644[ChargeOffData$IDRSSD == IDRSSD[i]];
    Loan_7[i]      <- LoanData$RCON1545[ChargeOffData$IDRSSD == IDRSSD[i]] +
                      LoanData$RCON1564[ChargeOffData$IDRSSD == IDRSSD[i]]; # +
    #LoanData$RCON2165[ChargeOffData$IDRSSD == IDRSSD[i]];
    
    
    #8. Leasing financing receivables:
    #a. To U.S. addressees (domicile) - 
    #leases to individuals for household, family, and other personal expenditures
    ChargeOff_8a[i] <- ChargeOffData$RIADF185[ChargeOffData$IDRSSD == IDRSSD[i]];
    # Need to use consolidated bank column
    Loan_8a[i]      <- LoanData$RCFDF162[ChargeOffData$IDRSSD == IDRSSD[i]];
    
    #b. To non-U.S. addressees (TO ALL OTHER LEASES)
    ChargeOff_8b[i] <- ChargeOffData$RIADC880[ChargeOffData$IDRSSD == IDRSSD[i]]; #CHANGED IN 3/31/2007
    Loan_8b[i]      <- LoanData$RCFDF163[ChargeOffData$IDRSSD == IDRSSD[i]];
    
    #9. Total
    ChargeOff_9[i] <- ChargeOffData$RIAD4635[ChargeOffData$IDRSSD == IDRSSD[i]];
    
    #Be conservative and use the domestic offices column - smaller denominator ~ larger charge-off
    Loan_9[i]      <- LoanData$RCON2122[ChargeOffData$IDRSSD == IDRSSD[i]];
    
    
    #1. - OTHER CATEGORY
    #a. To U.S. addressees (domicile)
    #ChargeOff_4[i] <- ChargeOffData$RIAD4655[ChargeOffData$IDRSSD == IDRSSD[i]];
  }
  
  NewJack <- data.frame(ChargeOff_1a/Loan_1a, ChargeOff_1b/Loan_1b, ChargeOff_1c1/Loan_1c1, 
                        ChargeOff_1c2/Loan_1c2, ChargeOff_1d/Loan_1d, ChargeOff_1e/Loan_1e, 
                        ChargeOff_2a/Loan_2a, ChargeOff_2b/Loan_2b, ChargeOff_2c/Loan_2c, 
                        ChargeOff_3/Loan_3, ChargeOff_4a/Loan_4a, ChargeOff_4b/Loan_4b, 
                        ChargeOff_5a/Loan_5a, ChargeOff_5b/Loan_5b, ChargeOff_5c/Loan_5c,
                        ChargeOff_6/Loan_6, 
                        ChargeOff_7/Loan_7, ChargeOff_8a/Loan_8a, ChargeOff_8b/Loan_8b, 
                        ChargeOff_9/Loan_9);
  
  return(NewJack)
}
